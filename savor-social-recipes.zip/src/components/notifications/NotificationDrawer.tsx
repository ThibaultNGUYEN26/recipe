import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Bell, Heart, MessageSquare, UserPlus, CheckCheck } from 'lucide-react';

export const NotificationDrawer: React.FC = () => {
  const {
    isNotificationDrawerOpen,
    setIsNotificationDrawerOpen,
    notifications,
    markNotificationsRead,
    openRecipeDetail
  } = useApp();

  if (!isNotificationDrawerOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-stone-900/50 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-stone-200 animate-in slide-in-from-right duration-250">
        {/* Drawer Header */}
        <div className="px-5 py-4 border-b border-stone-200/80 flex items-center justify-between bg-[#FAF8F5]">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-700" />
            <h2 className="font-serif text-lg font-bold text-stone-900">Notifications</h2>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={markNotificationsRead}
              className="text-xs font-semibold text-amber-800 hover:text-amber-900 flex items-center gap-1 hover:bg-amber-50 px-2.5 py-1 rounded-xl transition-colors"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>Mark all read</span>
            </button>
            <button
              onClick={() => setIsNotificationDrawerOpen(false)}
              className="p-1.5 text-stone-400 hover:text-stone-800 rounded-full hover:bg-stone-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="flex-1 overflow-y-auto divide-y divide-stone-100 p-2">
          {notifications.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-center p-6 text-stone-400">
              <Bell className="w-10 h-10 stroke-1 mb-2 text-stone-300" />
              <p className="text-sm font-bold text-stone-600">No notifications yet</p>
              <p className="text-xs text-stone-400 mt-1">Interactions with your recipes will show up here.</p>
            </div>
          ) : (
            notifications.map(n => {
              const icons = {
                like: <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />,
                comment: <MessageSquare className="w-3.5 h-3.5 text-sky-500" />,
                follow: <UserPlus className="w-3.5 h-3.5 text-amber-700" />,
                recipe_published: <Bell className="w-3.5 h-3.5 text-amber-700" />,
                rating: <Heart className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              };

              return (
                <div
                  key={n.id}
                  onClick={() => {
                    if (n.recipeId) {
                      openRecipeDetail(n.recipeId);
                      setIsNotificationDrawerOpen(false);
                    }
                  }}
                  className={`flex items-start gap-3 p-3.5 rounded-2xl transition-colors cursor-pointer ${
                    !n.read ? 'bg-amber-50/50 hover:bg-amber-50/80' : 'hover:bg-stone-50'
                  }`}
                >
                  <div className="relative shrink-0">
                    <img
                      src={n.actorAvatar}
                      alt={n.actorName}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="absolute -bottom-1 -right-1 bg-white p-1 rounded-full shadow-sm border border-stone-200">
                      {icons[n.type]}
                    </div>
                  </div>

                  <div className="min-w-0 flex-1">
                    <p className="text-xs text-stone-800 leading-snug">
                      <span className="font-bold text-stone-900">{n.actorName}</span>{' '}
                      {n.message || (n.recipeTitle ? `interacted with "${n.recipeTitle}"` : '')}
                    </p>
                    <p className="text-[10px] text-stone-400 font-medium mt-1">{n.timestamp}</p>
                  </div>

                  {!n.read && <span className="w-2 h-2 rounded-full bg-amber-600 shrink-0 mt-1" />}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
