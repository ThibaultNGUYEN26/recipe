import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Bell, Search, UserCheck, ChevronDown, Plus } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currentUser,
    users,
    switchActiveUser,
    unreadNotificationCount,
    setIsNotificationDrawerOpen,
    setActiveTab,
    activeTab
  } = useApp();

  const [isAccountMenuOpen, setIsAccountMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-[#FAF8F5]/90 backdrop-blur-md border-b border-stone-200/80 px-4 py-3 transition-all">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        {/* Brand Logo */}
        <button
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2 text-left focus:outline-none group"
        >
          <span className="font-serif text-2xl font-bold tracking-tight text-stone-900 group-hover:text-amber-800 transition-colors">
            SAVOR
          </span>
          <span className="text-[10px] font-semibold tracking-widest uppercase bg-amber-100 text-amber-900 px-1.5 py-0.5 rounded-full border border-amber-200/60 hidden sm:inline-block">
            SOCIAL RECIPES
          </span>
        </button>

        {/* Right Action Icons & Account Switcher */}
        <div className="flex items-center gap-2">
          {/* Quick Search Button */}
          {activeTab !== 'search' && (
            <button
              onClick={() => setActiveTab('search')}
              aria-label="Search recipes"
              className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-full transition-colors"
            >
              <Search className="w-5 h-5" />
            </button>
          )}

          {/* Quick Add Button on Desktop */}
          <button
            onClick={() => setActiveTab('add')}
            className="hidden sm:flex items-center gap-1.5 bg-stone-900 text-stone-50 px-3 py-1.5 rounded-full text-xs font-medium hover:bg-amber-900 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Recipe</span>
          </button>

          {/* Notifications Bell */}
          <button
            onClick={() => setIsNotificationDrawerOpen(true)}
            aria-label="Notifications"
            className="relative p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-full transition-colors"
          >
            <Bell className="w-5 h-5" />
            {unreadNotificationCount > 0 && (
              <span className="absolute top-1 right-1 bg-amber-600 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {unreadNotificationCount}
              </span>
            )}
          </button>

          {/* Account Selector Avatar Dropdown */}
          <div className="relative">
            <button
              onClick={() => setIsAccountMenuOpen(!isAccountMenuOpen)}
              className="flex items-center gap-1.5 p-1 rounded-full hover:bg-stone-200/50 transition-colors focus:outline-none"
            >
              <img
                src={currentUser.avatar}
                alt={currentUser.name}
                className="w-8 h-8 rounded-full object-cover ring-2 ring-amber-600/30"
              />
              <ChevronDown className="w-3.5 h-3.5 text-stone-500 hidden sm:block" />
            </button>

            {/* Account Switcher Dropdown Menu */}
            {isAccountMenuOpen && (
              <>
                <div
                  className="fixed inset-0 z-10"
                  onClick={() => setIsAccountMenuOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-stone-200/80 py-2 z-20 animate-in fade-in slide-in-from-top-2 duration-150">
                  <div className="px-4 py-2 border-b border-stone-100">
                    <p className="text-xs font-semibold text-stone-400 uppercase tracking-wider">
                      Current Cook
                    </p>
                    <p className="text-sm font-bold text-stone-900 truncate">{currentUser.name}</p>
                    <p className="text-xs text-stone-500 truncate">@{currentUser.username}</p>
                  </div>

                  <div className="py-1">
                    <p className="px-4 py-1 text-[11px] font-medium text-stone-400 uppercase tracking-wider">
                      Switch Account (Demo)
                    </p>
                    {users.map(u => (
                      <button
                        key={u.id}
                        onClick={() => {
                          switchActiveUser(u.id);
                          setIsAccountMenuOpen(false);
                        }}
                        className={`w-full flex items-center justify-between px-4 py-2 text-left hover:bg-amber-50/60 transition-colors ${
                          u.id === currentUser.id ? 'bg-amber-50/40 text-amber-900 font-medium' : 'text-stone-700'
                        }`}
                      >
                        <div className="flex items-center gap-2.5 min-w-0">
                          <img src={u.avatar} alt={u.name} className="w-7 h-7 rounded-full object-cover shrink-0" />
                          <div className="min-w-0">
                            <p className="text-xs font-semibold truncate">{u.name}</p>
                            <p className="text-[10px] text-stone-500 truncate">@{u.username}</p>
                          </div>
                        </div>
                        {u.id === currentUser.id && <UserCheck className="w-4 h-4 text-amber-700 shrink-0" />}
                      </button>
                    ))}
                  </div>

                  <div className="border-t border-stone-100 pt-1 mt-1 px-2">
                    <button
                      onClick={() => {
                        setActiveTab('profile');
                        setIsAccountMenuOpen(false);
                      }}
                      className="w-full text-center px-3 py-1.5 text-xs font-medium text-stone-700 hover:bg-stone-100 rounded-xl transition-colors"
                    >
                      View Profile
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
