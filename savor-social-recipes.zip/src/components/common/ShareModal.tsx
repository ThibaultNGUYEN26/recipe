import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Copy, Check, Share2, MessageCircle, Send } from 'lucide-react';

export const ShareModal: React.FC = () => {
  const { shareModalRecipe, setShareModalRecipe, showToast } = useApp();
  const [copied, setCopied] = useState(false);

  if (!shareModalRecipe) return null;

  const shareUrl = `${window.location.origin}?recipe=${shareModalRecipe.id}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    showToast('Link Copied!', 'Recipe URL copied to clipboard', 'success');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-stone-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl border border-stone-100 animate-in slide-in-from-bottom-4 duration-250">
        <div className="flex items-center justify-between pb-4 border-b border-stone-100">
          <div className="flex items-center gap-2">
            <Share2 className="w-5 h-5 text-amber-700" />
            <h3 className="font-serif text-lg font-bold text-stone-900">Share Recipe</h3>
          </div>
          <button
            onClick={() => setShareModalRecipe(null)}
            className="p-1.5 text-stone-400 hover:text-stone-800 rounded-full hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Recipe Preview Card */}
        <div className="flex items-center gap-3 bg-stone-50 p-3 rounded-2xl border border-stone-200/80 my-4">
          <img
            src={shareModalRecipe.coverImage}
            alt={shareModalRecipe.title}
            className="w-16 h-16 rounded-xl object-cover shrink-0"
          />
          <div className="min-w-0 flex-1">
            <h4 className="text-sm font-bold text-stone-900 truncate">{shareModalRecipe.title}</h4>
            <p className="text-xs text-stone-500 truncate">by @{shareModalRecipe.creatorUsername}</p>
            <p className="text-[11px] text-amber-800 font-medium mt-1">
              ⏱ {shareModalRecipe.totalTimeMinutes} mins • ⭐ {shareModalRecipe.averageRating}
            </p>
          </div>
        </div>

        {/* Copy Link Input */}
        <div className="space-y-3">
          <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
            Recipe Link
          </label>
          <div className="flex items-center gap-2">
            <input
              type="text"
              readOnly
              value={shareUrl}
              className="w-full bg-stone-100 text-stone-700 text-xs px-3 py-2.5 rounded-xl border border-stone-200 focus:outline-none truncate font-mono"
            />
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 bg-stone-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl hover:bg-amber-800 transition-colors shrink-0"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Quick Social Triggers */}
        <div className="grid grid-cols-3 gap-3 pt-5">
          <button
            onClick={() => {
              window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(`Check out this recipe: ${shareModalRecipe.title} - ${shareUrl}`)}`, '_blank');
            }}
            className="flex flex-col items-center justify-center p-3 bg-emerald-50 text-emerald-800 rounded-2xl hover:bg-emerald-100 transition-colors"
          >
            <MessageCircle className="w-5 h-5 mb-1" />
            <span className="text-[11px] font-medium">WhatsApp</span>
          </button>
          <button
            onClick={() => {
              window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(`Cooking "${shareModalRecipe.title}" on Savor!`)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
            }}
            className="flex flex-col items-center justify-center p-3 bg-sky-50 text-sky-800 rounded-2xl hover:bg-sky-100 transition-colors"
          >
            <Send className="w-5 h-5 mb-1" />
            <span className="text-[11px] font-medium">X / Twitter</span>
          </button>
          <button
            onClick={handleCopy}
            className="flex flex-col items-center justify-center p-3 bg-amber-50 text-amber-900 rounded-2xl hover:bg-amber-100 transition-colors"
          >
            <Share2 className="w-5 h-5 mb-1" />
            <span className="text-[11px] font-medium">Copy URL</span>
          </button>
        </div>
      </div>
    </div>
  );
};
