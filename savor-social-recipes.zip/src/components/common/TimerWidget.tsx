import React from 'react';
import { useApp } from '../../context/AppContext';
import { Timer, Square, Play } from 'lucide-react';

export const TimerWidget: React.FC = () => {
  const { activeTimer, stopCookingTimer } = useApp();

  if (!activeTimer) return null;

  const minutes = Math.floor(activeTimer.remainingSeconds / 60);
  const seconds = activeTimer.remainingSeconds % 60;
  const formattedTime = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  const percentage = Math.max(0, Math.min(100, (activeTimer.remainingSeconds / activeTimer.totalSeconds) * 100));

  return (
    <div className="fixed bottom-20 sm:bottom-24 right-4 z-40 bg-stone-900 text-stone-100 p-3.5 rounded-2xl shadow-2xl border border-stone-700/80 w-72 animate-in slide-in-from-bottom-5 duration-200">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2 min-w-0">
          <Timer className="w-4 h-4 text-amber-400 shrink-0 animate-pulse" />
          <p className="text-xs font-bold text-stone-200 truncate">{activeTimer.title}</p>
        </div>
        <button
          onClick={stopCookingTimer}
          aria-label="Cancel timer"
          className="p-1 hover:bg-stone-800 rounded-lg text-stone-400 hover:text-stone-100 transition-colors"
        >
          <Square className="w-3.5 h-3.5 text-rose-400 fill-rose-400" />
        </button>
      </div>

      <div className="flex items-center justify-between">
        <p className="font-mono text-2xl font-black text-amber-400 tracking-wider">
          {formattedTime}
        </p>
        <span className="text-[10px] text-stone-400 font-medium truncate max-w-[120px]">
          {activeTimer.recipeTitle}
        </span>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-stone-800 h-1.5 rounded-full overflow-hidden mt-2">
        <div
          className="bg-amber-500 h-full transition-all duration-1000 ease-linear"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  );
};
