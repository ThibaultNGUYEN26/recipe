import React from 'react';
import { useApp } from '../../context/AppContext';
import { Home, Search, PlusCircle, Bookmark, User as UserIcon } from 'lucide-react';
import { TabType } from '../../types';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, currentUser } = useApp();

  const navItems: { id: TabType; label: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'search', label: 'Discover', icon: Search },
    { id: 'add', label: 'Add', icon: PlusCircle },
    { id: 'saved', label: 'Saved', icon: Bookmark },
    { id: 'profile', label: 'Profile', icon: UserIcon }
  ];

  return (
    <>
      {/* Fixed Bottom Navigation Bar for Mobile */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#FAF8F5]/95 backdrop-blur-lg border-t border-stone-200/90 py-2 px-3 sm:hidden transition-all shadow-lg">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center py-1 px-3 rounded-2xl transition-all duration-200 relative ${
                  isActive
                    ? 'text-amber-800 font-semibold'
                    : 'text-stone-500 hover:text-stone-800'
                }`}
              >
                {/* Active Indicator dot or background pill */}
                {isActive && (
                  <span className="absolute -top-1 w-1 h-1 bg-amber-700 rounded-full" />
                )}
                {item.id === 'profile' ? (
                  <div className={`relative p-0.5 rounded-full ${isActive ? 'ring-2 ring-amber-700' : ''}`}>
                    <img
                      src={currentUser.avatar}
                      alt="Profile"
                      className="w-5 h-5 rounded-full object-cover"
                    />
                  </div>
                ) : (
                  <Icon
                    className={`w-5 h-5 transition-transform duration-200 ${
                      isActive ? 'scale-110 stroke-[2.5]' : 'stroke-[1.8]'
                    }`}
                  />
                )}
                <span className="text-[10px] mt-1 font-medium tracking-wide">
                  {item.label}
                </span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Floating Side/Bottom Navigation pill on Medium/Large Desktop screens */}
      <div className="hidden sm:block fixed bottom-6 left-1/2 -translate-x-1/2 z-40 bg-stone-900/95 backdrop-blur-xl border border-stone-800 text-stone-200 py-2 px-3 rounded-full shadow-2xl transition-all">
        <div className="flex items-center gap-1">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-xs font-semibold transition-all duration-200 ${
                  isActive
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'text-stone-400 hover:text-stone-100 hover:bg-stone-800/60'
                }`}
              >
                {item.id === 'profile' ? (
                  <img
                    src={currentUser.avatar}
                    alt="Profile"
                    className="w-4 h-4 rounded-full object-cover"
                  />
                ) : (
                  <Icon className="w-4 h-4" />
                )}
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </>
  );
};
