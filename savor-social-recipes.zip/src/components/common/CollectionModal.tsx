import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Plus, FolderPlus, Lock, Unlock, Bookmark, Check } from 'lucide-react';

export const CollectionModal: React.FC = () => {
  const {
    saveCollectionModalRecipeId,
    setSaveCollectionModalRecipeId,
    collections,
    createCollection,
    toggleSaveRecipe,
    recipes
  } = useApp();

  const [isCreatingNew, setIsCreatingNew] = useState(false);
  const [newColName, setNewColName] = useState('');
  const [newColDesc, setNewColDesc] = useState('');
  const [isPrivate, setIsPrivate] = useState(false);

  if (!saveCollectionModalRecipeId) return null;

  const targetRecipe = recipes.find(r => r.id === saveCollectionModalRecipeId);

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newColName.trim()) return;
    const newCol = createCollection(newColName.trim(), newColDesc.trim(), isPrivate);
    // Save recipe into new collection
    toggleSaveRecipe(saveCollectionModalRecipeId, newCol.id);
    setIsCreatingNew(false);
    setNewColName('');
    setNewColDesc('');
    setSaveCollectionModalRecipeId(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-stone-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl border border-stone-100 animate-in slide-in-from-bottom-4 duration-250">
        <div className="flex items-center justify-between pb-4 border-b border-stone-100">
          <div className="flex items-center gap-2">
            <Bookmark className="w-5 h-5 text-amber-700" />
            <h3 className="font-serif text-lg font-bold text-stone-900">Save to Collection</h3>
          </div>
          <button
            onClick={() => setSaveCollectionModalRecipeId(null)}
            className="p-1.5 text-stone-400 hover:text-stone-800 rounded-full hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {targetRecipe && (
          <p className="text-xs font-medium text-stone-500 my-3">
            Select collection for <span className="font-semibold text-stone-800">"{targetRecipe.title}"</span>
          </p>
        )}

        {!isCreatingNew ? (
          <div className="space-y-3">
            <div className="max-h-60 overflow-y-auto space-y-2 pr-1">
              {collections.map(col => {
                const isSavedInCol = targetRecipe?.savedInCollectionIds.includes(col.id);
                return (
                  <button
                    key={col.id}
                    onClick={() => {
                      toggleSaveRecipe(saveCollectionModalRecipeId, col.id);
                      setSaveCollectionModalRecipeId(null);
                    }}
                    className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all ${
                      isSavedInCol
                        ? 'bg-amber-50/70 border-amber-300 text-amber-950 font-medium'
                        : 'bg-stone-50 border-stone-200/80 text-stone-800 hover:bg-stone-100'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-stone-200/60 flex items-center justify-center shrink-0">
                        {col.isPrivate ? (
                          <Lock className="w-4 h-4 text-stone-600" />
                        ) : (
                          <Bookmark className="w-4 h-4 text-amber-800" />
                        )}
                      </div>
                      <div className="text-left min-w-0">
                        <p className="text-xs font-bold truncate">{col.name}</p>
                        <p className="text-[10px] text-stone-500">
                          {col.recipeIds.length} {col.recipeIds.length === 1 ? 'recipe' : 'recipes'}
                        </p>
                      </div>
                    </div>
                    {isSavedInCol && <Check className="w-4 h-4 text-amber-700 shrink-0" />}
                  </button>
                );
              })}
            </div>

            <button
              onClick={() => setIsCreatingNew(true)}
              className="w-full flex items-center justify-center gap-2 py-3 border-2 border-dashed border-stone-300 hover:border-amber-700 text-stone-700 hover:text-amber-800 text-xs font-semibold rounded-2xl transition-colors mt-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Collection</span>
            </button>
          </div>
        ) : (
          <form onSubmit={handleCreate} className="space-y-4 my-2">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                Collection Name
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Summer Barbecue, Italian Pastas"
                value={newColName}
                onChange={e => setNewColName(e.target.value)}
                className="w-full bg-stone-100 border border-stone-200 text-stone-900 text-xs rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-amber-800/30"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                Description (Optional)
              </label>
              <input
                type="text"
                placeholder="Short note about what goes in here..."
                value={newColDesc}
                onChange={e => setNewColDesc(e.target.value)}
                className="w-full bg-stone-100 border border-stone-200 text-stone-900 text-xs rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-amber-800/30"
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-stone-50 rounded-2xl border border-stone-200">
              <div className="flex items-center gap-2.5">
                {isPrivate ? <Lock className="w-4 h-4 text-amber-800" /> : <Unlock className="w-4 h-4 text-stone-500" />}
                <div>
                  <p className="text-xs font-bold text-stone-800">Private Collection</p>
                  <p className="text-[10px] text-stone-500">Only visible to you on your profile</p>
                </div>
              </div>
              <input
                type="checkbox"
                checked={isPrivate}
                onChange={e => setIsPrivate(e.target.checked)}
                className="w-4 h-4 text-amber-800 rounded focus:ring-amber-800"
              />
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsCreatingNew(false)}
                className="flex-1 py-2.5 text-xs font-semibold text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
              >
                Back
              </button>
              <button
                type="submit"
                className="flex-1 py-2.5 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-xl transition-colors shadow-sm"
              >
                Create & Save
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
