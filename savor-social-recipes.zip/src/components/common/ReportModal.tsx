import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { X, Flag, AlertCircle } from 'lucide-react';

export const ReportModal: React.FC = () => {
  const { reportModalItem, setReportModalItem, showToast } = useApp();
  const [reason, setReason] = useState('Spam or misleading');
  const [notes, setNotes] = useState('');

  if (!reportModalItem) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    showToast('Report Submitted', 'Thank you for keeping Savor safe and welcoming.', 'info');
    setReportModalItem(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-stone-100 animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-4 border-b border-stone-100">
          <div className="flex items-center gap-2">
            <Flag className="w-5 h-5 text-amber-700" />
            <h3 className="font-serif text-lg font-bold text-stone-900">Report Content</h3>
          </div>
          <button
            onClick={() => setReportModalItem(null)}
            className="p-1.5 text-stone-400 hover:text-stone-800 rounded-full hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          <div className="flex items-center gap-2 p-3 bg-amber-50 rounded-2xl border border-amber-200/60 text-amber-900 text-xs">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-700" />
            <span>Help us maintain high quality culinary standards. Select the reason for reporting this {reportModalItem.type}.</span>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Reason
            </label>
            <select
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full bg-stone-100 border border-stone-200 text-stone-900 text-sm rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-amber-800/30 font-medium"
            >
              <option value="Spam or misleading">Spam or misleading information</option>
              <option value="Inaccurate recipe or dangerous steps">Inaccurate measurements or dangerous steps</option>
              <option value="Offensive or inappropriate language">Offensive or inappropriate language</option>
              <option value="Copyright violation">Copyright infringement</option>
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
              Additional Details (Optional)
            </label>
            <textarea
              rows={3}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="Provide any specific details..."
              className="w-full bg-stone-100 border border-stone-200 text-stone-900 text-xs rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-amber-800/30 resize-none"
            />
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              type="button"
              onClick={() => setReportModalItem(null)}
              className="flex-1 px-4 py-2.5 text-xs font-semibold text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2.5 text-xs font-semibold text-white bg-amber-700 hover:bg-amber-800 rounded-xl transition-colors shadow-sm"
            >
              Submit Report
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
