import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, Info, AlertTriangle } from 'lucide-react';

export const Toast: React.FC = () => {
  const { toast } = useApp();

  if (!toast) return null;

  const icons = {
    success: <CheckCircle2 className="w-5 h-5 text-amber-500 shrink-0" />,
    info: <Info className="w-5 h-5 text-sky-500 shrink-0" />,
    warn: <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
  };

  return (
    <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-sm pointer-events-none animate-in fade-in slide-in-from-top-4 duration-300">
      <div className="bg-stone-900/95 backdrop-blur-md text-stone-100 p-3.5 rounded-2xl shadow-2xl border border-stone-800 flex items-start gap-3 pointer-events-auto">
        {icons[toast.type || 'success']}
        <div className="min-w-0 flex-1">
          <p className="text-xs font-bold text-stone-100">{toast.title}</p>
          {toast.desc && <p className="text-[11px] text-stone-400 mt-0.5 leading-snug">{toast.desc}</p>}
        </div>
      </div>
    </div>
  );
};
