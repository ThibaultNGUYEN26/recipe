import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Bookmark, Lock, Plus, Folder, Sparkles, Star, Clock } from 'lucide-react';

export const SavedRecipes: React.FC = () => {
  const {
    collections,
    recipes,
    openRecipeDetail,
    setSaveCollectionModalRecipeId,
    createCollection
  } = useApp();

  const [selectedCollectionId, setSelectedCollectionId] = useState<string | 'all'>('all');

  // Filter collections and recipes
  const currentCollection = collections.find(c => c.id === selectedCollectionId);

  const savedRecipes = recipes.filter(r => {
    if (!r.isSaved) return false;
    if (selectedCollectionId === 'all') return true;
    return r.savedInCollectionIds.includes(selectedCollectionId);
  });

  return (
    <div className="space-y-6 pb-20">
      {/* Page Title & Header */}
      <div className="flex items-center justify-between bg-white p-5 rounded-3xl border border-stone-200/80 shadow-sm">
        <div>
          <h1 className="font-serif text-2xl font-bold text-stone-900 flex items-center gap-2">
            <Bookmark className="w-6 h-6 text-amber-800" />
            <span>Saved Collections</span>
          </h1>
          <p className="text-xs text-stone-500 mt-0.5">Your organized culinary cookbook & meal plans</p>
        </div>

        <button
          onClick={() => setSaveCollectionModalRecipeId(recipes[0]?.id || '')}
          className="flex items-center gap-1.5 bg-stone-900 text-white text-xs font-bold px-3.5 py-2 rounded-2xl hover:bg-amber-800 transition-colors shadow-sm"
        >
          <Plus className="w-4 h-4" />
          <span>New Collection</span>
        </button>
      </div>

      {/* Collections Tabs Row */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setSelectedCollectionId('all')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all shrink-0 ${
            selectedCollectionId === 'all'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <Folder className="w-4 h-4" />
          <span>All Saved ({recipes.filter(r => r.isSaved).length})</span>
        </button>

        {collections.map(col => {
          const isActive = selectedCollectionId === col.id;
          return (
            <button
              key={col.id}
              onClick={() => setSelectedCollectionId(col.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all shrink-0 ${
                isActive
                  ? 'bg-amber-800 text-white shadow-sm'
                  : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50'
              }`}
            >
              {col.isPrivate && <Lock className="w-3.5 h-3.5 text-stone-400" />}
              <span>{col.name} ({col.recipeIds.length})</span>
            </button>
          );
        })}
      </div>

      {/* Collection Detail Info Banner */}
      {currentCollection && (
        <div className="bg-amber-50/80 p-4 rounded-2xl border border-amber-200/80 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-serif text-base font-bold text-amber-950">{currentCollection.name}</h3>
              {currentCollection.isPrivate && (
                <span className="text-[10px] font-bold bg-amber-200/80 text-amber-900 px-2 py-0.5 rounded-full flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  Private
                </span>
              )}
            </div>
            {currentCollection.description && (
              <p className="text-xs text-amber-900/80 mt-0.5 font-medium">{currentCollection.description}</p>
            )}
          </div>
        </div>
      )}

      {/* Saved Recipes Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {savedRecipes.map(recipe => (
          <div
            key={recipe.id}
            onClick={() => openRecipeDetail(recipe.id)}
            className="bg-white rounded-3xl overflow-hidden border border-stone-200/80 shadow-sm hover:shadow-md transition-all duration-200 cursor-pointer group flex flex-col"
          >
            <div className="relative aspect-[16/10] overflow-hidden bg-stone-100">
              <img
                src={recipe.coverImage}
                alt={recipe.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute top-3 left-3 bg-stone-900/80 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase">
                {recipe.cuisine}
              </div>
              <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md text-stone-900 px-2 py-0.5 rounded-full text-xs font-bold flex items-center gap-1">
                <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                {recipe.averageRating.toFixed(1)}
              </div>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <h3 className="font-serif text-base font-bold text-stone-900 group-hover:text-amber-800 transition-colors line-clamp-1">
                  {recipe.title}
                </h3>
                <p className="text-xs text-stone-500 mt-1">by @{recipe.creatorUsername}</p>
              </div>

              <div className="flex items-center justify-between text-xs font-semibold text-stone-500 mt-3 pt-3 border-t border-stone-100">
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-amber-700" />
                  {recipe.totalTimeMinutes} mins
                </span>
                <span className="text-amber-800 font-bold text-[11px]">
                  {recipe.savedInCollectionIds.length} collections
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {savedRecipes.length === 0 && (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200">
          <Bookmark className="w-12 h-12 text-stone-300 mx-auto mb-3" />
          <h3 className="font-serif text-lg font-bold text-stone-800">No saved recipes here yet</h3>
          <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
            Browse the feed or discover tab and tap the bookmark icon to save recipes to your collections.
          </p>
        </div>
      )}
    </div>
  );
};
