import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RecipeCard } from '../home/RecipeCard';
import { User, Recipe } from '../../types';
import {
  Edit3,
  MapPin,
  Users,
  Utensils,
  Heart,
  Bookmark,
  X,
  Sparkles,
  Camera,
  Star
} from 'lucide-react';

export const UserProfile: React.FC = () => {
  const { currentUser, recipes, collections, updateUserProfile, openRecipeDetail } = useApp();

  const [activeTab, setActiveTab] = useState<'recipes' | 'saved' | 'liked'>('recipes');
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Edit form state
  const [editName, setEditName] = useState(currentUser.name);
  const [editUsername, setEditUsername] = useState(currentUser.username);
  const [editBio, setEditBio] = useState(currentUser.bio);
  const [editLocation, setEditLocation] = useState(currentUser.location);
  const [editAvatar, setEditAvatar] = useState(currentUser.avatar);

  const publishedRecipes = recipes.filter(r => r.creatorId === currentUser.id);
  const likedRecipes = recipes.filter(r => r.isLiked);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      name: editName,
      username: editUsername,
      bio: editBio,
      location: editLocation,
      avatar: editAvatar
    });
    setIsEditModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Profile Header Card */}
      <section className="bg-white p-6 sm:p-8 rounded-3xl border border-stone-200/80 shadow-sm space-y-5">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5 text-center sm:text-left">
          <img
            src={currentUser.avatar}
            alt={currentUser.name}
            className="w-24 h-24 sm:w-28 sm:h-28 rounded-full object-cover ring-4 ring-amber-700/20 shadow-md shrink-0"
          />

          <div className="flex-1 min-w-0 space-y-2">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h1 className="font-serif text-2xl font-black text-stone-900">{currentUser.name}</h1>
                <p className="text-xs font-semibold text-stone-500">@{currentUser.username}</p>
              </div>

              <button
                onClick={() => setIsEditModalOpen(true)}
                className="flex items-center gap-1.5 bg-stone-900 text-white text-xs font-bold px-4 py-2 rounded-2xl hover:bg-amber-800 transition-colors shadow-sm"
              >
                <Edit3 className="w-3.5 h-3.5" />
                <span>Edit Profile</span>
              </button>
            </div>

            <p className="text-xs text-stone-700 font-normal leading-relaxed max-w-xl">
              {currentUser.bio}
            </p>

            <div className="flex items-center justify-center sm:justify-start gap-1 text-xs font-medium text-stone-500">
              <MapPin className="w-3.5 h-3.5 text-amber-800" />
              <span>{currentUser.location}</span>
            </div>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-3 gap-2 pt-4 border-t border-stone-100 text-center">
          <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200/60">
            <p className="font-serif text-xl font-bold text-stone-900">{publishedRecipes.length}</p>
            <p className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">Recipes</p>
          </div>
          <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200/60">
            <p className="font-serif text-xl font-bold text-stone-900">{currentUser.followersCount}</p>
            <p className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">Followers</p>
          </div>
          <div className="bg-stone-50 p-3 rounded-2xl border border-stone-200/60">
            <p className="font-serif text-xl font-bold text-stone-900">{currentUser.followingCount}</p>
            <p className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">Following</p>
          </div>
        </div>
      </section>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-stone-200/80 pb-2">
        <button
          onClick={() => setActiveTab('recipes')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all ${
            activeTab === 'recipes'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <Utensils className="w-4 h-4" />
          <span>My Recipes ({publishedRecipes.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('saved')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all ${
            activeTab === 'saved'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <Bookmark className="w-4 h-4" />
          <span>Collections ({collections.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('liked')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all ${
            activeTab === 'liked'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-white text-stone-700 border border-stone-200 hover:bg-stone-50'
          }`}
        >
          <Heart className="w-4 h-4" />
          <span>Liked ({likedRecipes.length})</span>
        </button>
      </div>

      {/* TAB CONTENTS */}
      {activeTab === 'recipes' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {publishedRecipes.map(recipe => (
            <RecipeCard key={recipe.id} recipe={recipe} />
          ))}

          {publishedRecipes.length === 0 && (
            <div className="col-span-full bg-white rounded-3xl p-12 text-center border border-stone-200">
              <Utensils className="w-12 h-12 text-stone-300 mx-auto mb-3" />
              <h3 className="font-serif text-lg font-bold text-stone-800">You haven't published any recipes yet</h3>
              <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
                Share your signature dish with the Savor community!
              </p>
            </div>
          )}
        </div>
      )}

      {activeTab === 'saved' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {collections.map(col => (
            <div
              key={col.id}
              className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm flex flex-col justify-between space-y-3"
            >
              <div>
                <h3 className="font-serif text-base font-bold text-stone-900">{col.name}</h3>
                <p className="text-xs text-stone-500 mt-0.5">{col.description || 'Custom recipe folder'}</p>
              </div>

              <div className="flex items-center justify-between text-xs font-semibold text-stone-600 pt-3 border-t border-stone-100">
                <span>{col.recipeIds.length} recipes</span>
                <span className="text-[10px] text-stone-400">Created {col.createdAt}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'liked' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {likedRecipes.map(recipe => (
            <div
              key={recipe.id}
              onClick={() => openRecipeDetail(recipe.id)}
              className="group relative aspect-square rounded-2xl overflow-hidden bg-stone-100 cursor-pointer shadow-sm border border-stone-200"
            >
              <img
                src={recipe.coverImage}
                alt={recipe.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent p-3 flex flex-col justify-end">
                <p className="text-xs font-bold text-white line-clamp-1">{recipe.title}</p>
                <p className="text-[10px] text-stone-300">by @{recipe.creatorUsername}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Edit Profile Modal */}
      {isEditModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-stone-100 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-serif text-lg font-bold text-stone-900">Edit Profile</h3>
              <button onClick={() => setIsEditModalOpen(false)} className="p-1 text-stone-400 hover:text-stone-800">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProfile} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-500 uppercase">Display Name</label>
                <input
                  type="text"
                  required
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 text-xs font-bold rounded-xl px-3 py-2.5 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-500 uppercase">Username</label>
                <input
                  type="text"
                  required
                  value={editUsername}
                  onChange={e => setEditUsername(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 text-xs font-bold rounded-xl px-3 py-2.5 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-500 uppercase">Biography</label>
                <textarea
                  rows={3}
                  value={editBio}
                  onChange={e => setEditBio(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 text-xs rounded-xl p-3 focus:outline-none resize-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-500 uppercase">Location</label>
                <input
                  type="text"
                  value={editLocation}
                  onChange={e => setEditLocation(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 text-xs font-bold rounded-xl px-3 py-2.5 focus:outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-xs font-bold text-stone-500 uppercase">Avatar Image URL</label>
                <input
                  type="text"
                  value={editAvatar}
                  onChange={e => setEditAvatar(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 text-xs rounded-xl px-3 py-2.5 focus:outline-none font-mono"
                />
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditModalOpen(false)}
                  className="flex-1 py-2.5 text-xs font-bold text-stone-600 bg-stone-100 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 text-xs font-bold text-white bg-amber-800 hover:bg-amber-900 rounded-xl shadow-sm"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
