import React from 'react';
import { Recipe } from '../../types';
import { useApp } from '../../context/AppContext';
import { Heart, MessageCircle, Bookmark, Star, Clock, ChefHat, Share2, UserPlus, UserCheck } from 'lucide-react';

interface RecipeCardProps {
  recipe: Recipe;
}

export const RecipeCard: React.FC<RecipeCardProps> = ({ recipe }) => {
  const {
    openRecipeDetail,
    toggleLikeRecipe,
    setSaveCollectionModalRecipeId,
    toggleFollowUser,
    setShareModalRecipe,
    currentUser
  } = useApp();

  const isOwnRecipe = recipe.creatorId === currentUser.id;

  return (
    <article className="bg-white rounded-3xl overflow-hidden border border-stone-200/80 shadow-sm hover:shadow-md transition-all duration-200 group">
      {/* Creator Header */}
      <div className="flex items-center justify-between p-3.5 sm:p-4">
        <div className="flex items-center gap-3 min-w-0">
          <img
            src={recipe.creatorAvatar}
            alt={recipe.creatorName}
            className="w-10 h-10 rounded-full object-cover ring-2 ring-stone-100 shrink-0"
          />
          <div className="min-w-0">
            <h4 className="text-xs font-bold text-stone-900 truncate">{recipe.creatorName}</h4>
            <p className="text-[11px] text-stone-500 truncate">@{recipe.creatorUsername}</p>
          </div>
        </div>

        {!isOwnRecipe && (
          <button
            onClick={e => {
              e.stopPropagation();
              toggleFollowUser(recipe.creatorId);
            }}
            className={`flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-full transition-all ${
              recipe.creatorIsFollowed
                ? 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                : 'bg-amber-800 text-white hover:bg-amber-900 shadow-sm'
            }`}
          >
            {recipe.creatorIsFollowed ? (
              <>
                <UserCheck className="w-3.5 h-3.5 text-amber-700" />
                <span>Following</span>
              </>
            ) : (
              <>
                <UserPlus className="w-3.5 h-3.5" />
                <span>Follow</span>
              </>
            )}
          </button>
        )}
      </div>

      {/* Square Recipe Image Container */}
      <div
        onClick={() => openRecipeDetail(recipe.id)}
        className="relative aspect-square overflow-hidden bg-stone-100 cursor-pointer group-hover:opacity-98 transition-opacity"
      >
        <img
          src={recipe.coverImage}
          alt={recipe.title}
          loading="lazy"
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
        />

        {/* Floating Badges */}
        <div className="absolute top-3 left-3 flex flex-wrap gap-1.5 max-w-[80%]">
          <span className="bg-stone-900/80 backdrop-blur-md text-stone-50 text-[10px] font-semibold px-2.5 py-1 rounded-full uppercase tracking-wider">
            {recipe.cuisine}
          </span>
          {recipe.dietaryTags.slice(0, 2).map(tag => (
            <span
              key={tag}
              className="bg-amber-900/80 backdrop-blur-md text-amber-100 text-[10px] font-semibold px-2.5 py-1 rounded-full"
            >
              {tag}
            </span>
          ))}
        </div>

        {/* Rating Badge */}
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-md text-stone-900 px-2.5 py-1 rounded-full text-xs font-bold shadow-md flex items-center gap-1">
          <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
          <span>{recipe.averageRating.toFixed(1)}</span>
        </div>
      </div>

      {/* Content & Actions */}
      <div className="p-4 sm:p-5">
        <div onClick={() => openRecipeDetail(recipe.id)} className="cursor-pointer">
          <h3 className="font-serif text-lg sm:text-xl font-bold text-stone-900 group-hover:text-amber-800 transition-colors leading-snug">
            {recipe.title}
          </h3>
          <p className="text-xs text-stone-600 line-clamp-2 mt-1.5 leading-relaxed font-normal">
            {recipe.description}
          </p>
        </div>

        {/* Time & Difficulty bar */}
        <div className="flex items-center gap-4 text-xs font-semibold text-stone-500 mt-3 pt-3 border-t border-stone-100">
          <div className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-amber-700" />
            <span>{recipe.totalTimeMinutes} mins</span>
          </div>
          <div className="flex items-center gap-1">
            <ChefHat className="w-3.5 h-3.5 text-amber-700" />
            <span>{recipe.difficulty}</span>
          </div>
        </div>

        {/* Action Buttons Row */}
        <div className="flex items-center justify-between pt-4 mt-3 border-t border-stone-100">
          <div className="flex items-center gap-4">
            {/* Like */}
            <button
              onClick={() => toggleLikeRecipe(recipe.id)}
              className={`flex items-center gap-1.5 text-xs font-bold transition-all ${
                recipe.isLiked ? 'text-rose-600' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Heart
                className={`w-5 h-5 transition-transform active:scale-125 ${
                  recipe.isLiked ? 'fill-rose-600 text-rose-600' : 'stroke-[1.8]'
                }`}
              />
              <span>{recipe.likesCount}</span>
            </button>

            {/* Comment */}
            <button
              onClick={() => openRecipeDetail(recipe.id)}
              className="flex items-center gap-1.5 text-xs font-bold text-stone-600 hover:text-stone-900 transition-colors"
            >
              <MessageCircle className="w-5 h-5 stroke-[1.8]" />
              <span>{recipe.comments.length}</span>
            </button>

            {/* Share */}
            <button
              onClick={() => setShareModalRecipe(recipe)}
              className="text-stone-500 hover:text-stone-900 transition-colors"
              aria-label="Share recipe"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>

          {/* Bookmark / Save button */}
          <button
            onClick={() => setSaveCollectionModalRecipeId(recipe.id)}
            className={`p-2 rounded-full transition-all ${
              recipe.isSaved
                ? 'bg-amber-100 text-amber-900'
                : 'text-stone-500 hover:text-stone-900 hover:bg-stone-100'
            }`}
            aria-label="Save recipe"
          >
            <Bookmark
              className={`w-5 h-5 ${recipe.isSaved ? 'fill-amber-800 text-amber-800' : 'stroke-[1.8]'}`}
            />
          </button>
        </div>
      </div>
    </article>
  );
};
