import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { RecipeCard } from './RecipeCard';
import { Sparkles, Flame, Clock, Leaf, UtensilsCrossed } from 'lucide-react';

export const HomeFeed: React.FC = () => {
  const { recipes, currentUser, openRecipeDetail } = useApp();
  const [activeFeedFilter, setActiveFeedFilter] = useState<'all' | 'following' | 'trending' | 'quick' | 'vegetarian'>('all');

  // Filter recipes according to feed filter
  const filteredRecipes = recipes.filter(r => {
    if (activeFeedFilter === 'following') {
      return currentUser.followingUserIds.includes(r.creatorId) || r.creatorId === currentUser.id;
    }
    if (activeFeedFilter === 'trending') {
      return r.likesCount > 1000;
    }
    if (activeFeedFilter === 'quick') {
      return r.totalTimeMinutes <= 30;
    }
    if (activeFeedFilter === 'vegetarian') {
      return r.dietaryTags.includes('Vegetarian') || r.dietaryTags.includes('Vegan');
    }
    return true;
  });

  // Featured Hero recipe
  const featuredRecipe = recipes.find(r => r.likesCount > 2000) || recipes[0];

  return (
    <div className="space-y-6 pb-12">
      {/* Featured Recipe Hero Card */}
      {featuredRecipe && activeFeedFilter === 'all' && (
        <section
          onClick={() => openRecipeDetail(featuredRecipe.id)}
          className="relative rounded-3xl overflow-hidden bg-stone-900 text-white cursor-pointer shadow-xl group border border-stone-800"
        >
          <div className="relative aspect-[16/9] sm:aspect-[21/9] w-full">
            <img
              src={featuredRecipe.coverImage}
              alt={featuredRecipe.title}
              className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-700 ease-out"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950 via-stone-950/40 to-transparent" />
          </div>

          <div className="absolute bottom-0 inset-x-0 p-5 sm:p-8 flex flex-col justify-end">
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-amber-600 text-white text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-full flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Featured Recipe
              </span>
              <span className="text-stone-300 text-xs font-semibold">
                By {featuredRecipe.creatorName}
              </span>
            </div>

            <h2 className="font-serif text-2xl sm:text-3xl font-extrabold text-white leading-tight group-hover:text-amber-300 transition-colors">
              {featuredRecipe.title}
            </h2>

            <p className="text-stone-300 text-xs sm:text-sm line-clamp-2 mt-2 max-w-2xl font-light">
              {featuredRecipe.description}
            </p>

            <div className="flex items-center gap-4 text-xs font-medium text-stone-300 mt-4">
              <span>⏱ {featuredRecipe.totalTimeMinutes} mins</span>
              <span>•</span>
              <span>⭐ {featuredRecipe.averageRating.toFixed(1)} rating</span>
              <span>•</span>
              <span>❤️ {featuredRecipe.likesCount} cooks loved this</span>
            </div>
          </div>
        </section>
      )}

      {/* Feed Filters Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-stone-200/60 pt-2">
        <button
          onClick={() => setActiveFeedFilter('all')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
            activeFeedFilter === 'all'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>All Recipes</span>
        </button>

        <button
          onClick={() => setActiveFeedFilter('following')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
            activeFeedFilter === 'following'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
          }`}
        >
          <UtensilsCrossed className="w-3.5 h-3.5" />
          <span>Following Cooks</span>
        </button>

        <button
          onClick={() => setActiveFeedFilter('trending')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
            activeFeedFilter === 'trending'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
          }`}
        >
          <Flame className="w-3.5 h-3.5" />
          <span>Trending</span>
        </button>

        <button
          onClick={() => setActiveFeedFilter('quick')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
            activeFeedFilter === 'quick'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          <span>Under 30 Mins</span>
        </button>

        <button
          onClick={() => setActiveFeedFilter('vegetarian')}
          className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-xs font-semibold whitespace-nowrap transition-all ${
            activeFeedFilter === 'vegetarian'
              ? 'bg-amber-800 text-white shadow-sm'
              : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
          }`}
        >
          <Leaf className="w-3.5 h-3.5 text-emerald-600" />
          <span>Vegetarian</span>
        </button>
      </div>

      {/* Main Recipe Cards Feed */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredRecipes.map(recipe => (
          <RecipeCard key={recipe.id} recipe={recipe} />
        ))}
      </div>

      {filteredRecipes.length === 0 && (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200">
          <UtensilsCrossed className="w-12 h-12 text-stone-300 mx-auto mb-3" />
          <h3 className="font-serif text-lg font-bold text-stone-800">No recipes found</h3>
          <p className="text-xs text-stone-500 mt-1 max-w-sm mx-auto">
            Try switching feed filters or follow more cooks to populate your social feed.
          </p>
          <button
            onClick={() => setActiveFeedFilter('all')}
            className="mt-4 bg-amber-800 text-white text-xs font-semibold px-5 py-2.5 rounded-full hover:bg-amber-900 transition-colors"
          >
            Show All Recipes
          </button>
        </div>
      )}
    </div>
  );
};
