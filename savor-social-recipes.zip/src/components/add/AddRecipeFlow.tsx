import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Cuisine, Category, DietaryTag, Difficulty, Ingredient, Step } from '../../types';
import { PRESET_FOOD_IMAGES } from '../../data/mockData';
import {
  Plus,
  Trash2,
  MoveUp,
  MoveDown,
  Sparkles,
  Eye,
  CheckCircle2,
  Clock,
  ChefHat,
  Users,
  Image as ImageIcon,
  ArrowRight,
  ArrowLeft,
  X
} from 'lucide-react';

export const AddRecipeFlow: React.FC = () => {
  const { publishRecipe, setActiveTab, openRecipeDetail, showToast } = useApp();

  const [stepPage, setStepPage] = useState<1 | 2 | 3>(1);

  // Form Fields
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [coverImage, setCoverImage] = useState(PRESET_FOOD_IMAGES[0].url);
  const [prepTimeMinutes, setPrepTimeMinutes] = useState(15);
  const [cookTimeMinutes, setCookTimeMinutes] = useState(20);
  const [difficulty, setDifficulty] = useState<Difficulty>('Easy');
  const [servings, setServings] = useState(2);
  const [cuisine, setCuisine] = useState<Cuisine>('Italian');
  const [category, setCategory] = useState<Category>('Main Course');

  const [dietaryTags, setDietaryTags] = useState<DietaryTag[]>([]);
  const [allergenInfo, setAllergenInfo] = useState<string[]>([]);
  const [tipsInput, setTipsInput] = useState('');

  // Dynamic Ingredients List
  const [ingredients, setIngredients] = useState<Ingredient[]>([
    { id: '1', name: 'Fresh Tagliatelle Pasta', amount: 250, unit: 'g' },
    { id: '2', name: 'Wild Mushrooms', amount: 200, unit: 'g' }
  ]);

  // Dynamic Preparation Steps
  const [steps, setSteps] = useState<Step[]>([
    { id: '1', stepNumber: 1, title: 'Prep & Sear', instruction: 'Sear mushrooms in hot olive oil until golden brown.', timerMinutes: 5 },
    { id: '2', stepNumber: 2, title: 'Toss & Finish', instruction: 'Add butter, heavy cream, pasta, and fresh herbs.', timerMinutes: 3 }
  ]);

  const [showImagePicker, setShowImagePicker] = useState(false);
  const [showPreviewModal, setShowPreviewModal] = useState(false);

  const cuisinesList: Cuisine[] = ['Italian', 'Japanese', 'Mexican', 'Mediterranean', 'French', 'Nordic', 'Thai', 'Indian', 'Modern American'];
  const categoriesList: Category[] = ['Main Course', 'Dessert', 'Breakfast', 'Appetizer', 'Salad', 'Soup', 'Pasta', 'Baking', 'Drinks'];
  const dietaryList: DietaryTag[] = ['Vegetarian', 'Vegan', 'Gluten-Free', 'Dairy-Free', 'Low-Carb', 'Nut-Free', 'Keto'];

  // Ingredient Helpers
  const addIngredient = () => {
    const newId = Date.now().toString();
    setIngredients(prev => [...prev, { id: newId, name: '', amount: 1, unit: 'tbsp' }]);
  };

  const removeIngredient = (id: string) => {
    setIngredients(prev => prev.filter(i => i.id !== id));
  };

  const updateIngredient = (id: string, field: keyof Ingredient, value: any) => {
    setIngredients(prev =>
      prev.map(i => (i.id === id ? { ...i, [field]: value } : i))
    );
  };

  // Step Helpers
  const addStep = () => {
    const newId = Date.now().toString();
    const nextNum = steps.length + 1;
    setSteps(prev => [...prev, { id: newId, stepNumber: nextNum, instruction: '' }]);
  };

  const removeStep = (id: string) => {
    setSteps(prev => {
      const filtered = prev.filter(s => s.id !== id);
      return filtered.map((s, idx) => ({ ...s, stepNumber: idx + 1 }));
    });
  };

  const updateStep = (id: string, field: keyof Step, value: any) => {
    setSteps(prev =>
      prev.map(s => (s.id === id ? { ...s, [field]: value } : s))
    );
  };

  const moveStep = (index: number, direction: 'up' | 'down') => {
    if ((direction === 'up' && index === 0) || (direction === 'down' && index === steps.length - 1)) return;
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    const newSteps = [...steps];
    const temp = newSteps[index];
    newSteps[index] = newSteps[targetIdx];
    newSteps[targetIdx] = temp;
    setSteps(newSteps.map((s, idx) => ({ ...s, stepNumber: idx + 1 })));
  };

  const toggleDietaryTag = (tag: DietaryTag) => {
    setDietaryTags(prev =>
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCoverImage(reader.result as string);
        showToast('Image Loaded', 'Recipe image preview updated', 'success');
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePublish = () => {
    if (!title.trim()) {
      showToast('Title Required', 'Please enter a recipe name', 'warn');
      return;
    }

    const tipsArray = tipsInput
      .split('\n')
      .map(t => t.trim())
      .filter(Boolean);

    const created = publishRecipe({
      title: title.trim(),
      description: description.trim() || 'A delicious handmade recipe shared on Savor.',
      coverImage,
      prepTimeMinutes: Number(prepTimeMinutes) || 10,
      cookTimeMinutes: Number(cookTimeMinutes) || 15,
      totalTimeMinutes: (Number(prepTimeMinutes) || 10) + (Number(cookTimeMinutes) || 15),
      difficulty,
      servings: Number(servings) || 2,
      cuisine,
      category,
      dietaryTags,
      allergenInfo,
      tipsAndSubstitutions: tipsArray,
      ingredients: ingredients.filter(i => i.name.trim().length > 0),
      steps: steps.filter(s => s.instruction.trim().length > 0),
      isPublished: true
    });

    openRecipeDetail(created.id);
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6 pb-24">
      {/* Page Header */}
      <div className="bg-white p-5 rounded-3xl border border-stone-200/80 shadow-sm flex items-center justify-between">
        <div>
          <h1 className="font-serif text-2xl font-bold text-stone-900">Publish New Recipe</h1>
          <p className="text-xs text-stone-500 mt-0.5">Share your culinary masterpiece with the world</p>
        </div>

        <button
          onClick={() => setShowPreviewModal(true)}
          className="flex items-center gap-1.5 text-xs font-bold text-amber-900 bg-amber-50 hover:bg-amber-100 border border-amber-200 px-3 py-2 rounded-2xl transition-colors"
        >
          <Eye className="w-4 h-4 text-amber-800" />
          <span>Preview</span>
        </button>
      </div>

      {/* Stepper Progress Bar */}
      <div className="grid grid-cols-3 gap-2 bg-stone-100 p-1.5 rounded-2xl border border-stone-200">
        <button
          onClick={() => setStepPage(1)}
          className={`py-2 text-xs font-bold rounded-xl transition-all ${
            stepPage === 1 ? 'bg-amber-800 text-white shadow-sm' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          1. Basic Info
        </button>
        <button
          onClick={() => setStepPage(2)}
          className={`py-2 text-xs font-bold rounded-xl transition-all ${
            stepPage === 2 ? 'bg-amber-800 text-white shadow-sm' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          2. Ingredients & Steps
        </button>
        <button
          onClick={() => setStepPage(3)}
          className={`py-2 text-xs font-bold rounded-xl transition-all ${
            stepPage === 3 ? 'bg-amber-800 text-white shadow-sm' : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          3. Tags & Publish
        </button>
      </div>

      {/* STEP 1: BASIC INFO */}
      {stepPage === 1 && (
        <section className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm space-y-5 animate-in fade-in duration-200">
          {/* Cover Image Picker / Upload */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center justify-between">
              <span>Cover Food Photography</span>
              <button
                type="button"
                onClick={() => setShowImagePicker(true)}
                className="text-amber-800 hover:underline normal-case text-xs font-semibold"
              >
                Choose from preset library
              </button>
            </label>

            <div className="relative aspect-[16/9] w-full rounded-2xl overflow-hidden bg-stone-100 border border-stone-200 group">
              <img src={coverImage} alt="Cover Preview" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-stone-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                <label className="bg-white text-stone-900 text-xs font-bold px-4 py-2 rounded-xl cursor-pointer hover:bg-stone-100 transition-colors shadow-md">
                  Upload File
                  <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload} />
                </label>
                <button
                  type="button"
                  onClick={() => setShowImagePicker(true)}
                  className="bg-stone-900 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-amber-800 transition-colors shadow-md"
                >
                  Presets
                </button>
              </div>
            </div>
          </div>

          {/* Recipe Name & Description */}
          <div className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                Recipe Title *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder="e.g. Truffle & Wild Mushroom Tagliatelle"
                className="w-full bg-stone-50 border border-stone-200 text-stone-900 text-sm font-bold rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-amber-800/30"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                Short Description
              </label>
              <textarea
                rows={3}
                value={description}
                onChange={e => setDescription(e.target.value)}
                placeholder="Describe the texture, flavor notes, and story behind this dish..."
                className="w-full bg-stone-50 border border-stone-200 text-stone-900 text-xs rounded-xl p-3 focus:outline-none focus:ring-2 focus:ring-amber-800/30 resize-none font-medium"
              />
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
            <div>
              <label className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
                Prep Time (m)
              </label>
              <input
                type="number"
                min={1}
                value={prepTimeMinutes}
                onChange={e => setPrepTimeMinutes(Number(e.target.value))}
                className="w-full bg-stone-50 border border-stone-200 text-stone-900 text-xs font-bold rounded-xl px-3 py-2 mt-1 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
                Cook Time (m)
              </label>
              <input
                type="number"
                min={0}
                value={cookTimeMinutes}
                onChange={e => setCookTimeMinutes(Number(e.target.value))}
                className="w-full bg-stone-50 border border-stone-200 text-stone-900 text-xs font-bold rounded-xl px-3 py-2 mt-1 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
                Servings
              </label>
              <input
                type="number"
                min={1}
                value={servings}
                onChange={e => setServings(Number(e.target.value))}
                className="w-full bg-stone-50 border border-stone-200 text-stone-900 text-xs font-bold rounded-xl px-3 py-2 mt-1 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-bold text-stone-500 uppercase tracking-wider">
                Difficulty
              </label>
              <select
                value={difficulty}
                onChange={e => setDifficulty(e.target.value as Difficulty)}
                className="w-full bg-stone-50 border border-stone-200 text-stone-900 text-xs font-bold rounded-xl px-2 py-2 mt-1 focus:outline-none"
              >
                <option value="Easy">Easy</option>
                <option value="Medium">Medium</option>
                <option value="Hard">Hard</option>
                <option value="Chef">Chef</option>
              </select>
            </div>
          </div>

          <div className="flex justify-end pt-3">
            <button
              onClick={() => setStepPage(2)}
              className="flex items-center gap-2 bg-stone-900 text-white font-bold text-xs px-6 py-3 rounded-2xl hover:bg-amber-800 transition-colors shadow-md"
            >
              <span>Next: Ingredients & Steps</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </section>
      )}

      {/* STEP 2: INGREDIENTS & STEPS */}
      {stepPage === 2 && (
        <div className="space-y-6 animate-in fade-in duration-200">
          {/* Dynamic Ingredients Builder */}
          <section className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h2 className="font-serif text-lg font-bold text-stone-900">Ingredients List</h2>
                <p className="text-xs text-stone-500">Specify names, amounts, and units</p>
              </div>
              <button
                type="button"
                onClick={addIngredient}
                className="flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-xl transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Ingredient</span>
              </button>
            </div>

            <div className="space-y-2.5">
              {ingredients.map((ing, idx) => (
                <div key={ing.id} className="flex items-center gap-2 bg-stone-50 p-2.5 rounded-2xl border border-stone-200/80">
                  <span className="text-xs font-mono text-stone-400 w-5 text-center">{idx + 1}.</span>
                  <input
                    type="text"
                    placeholder="Ingredient name..."
                    value={ing.name}
                    onChange={e => updateIngredient(ing.id, 'name', e.target.value)}
                    className="flex-1 bg-white text-xs border border-stone-200 rounded-xl px-3 py-2 font-medium focus:outline-none"
                  />
                  <input
                    type="number"
                    step="any"
                    value={ing.amount}
                    onChange={e => updateIngredient(ing.id, 'amount', Number(e.target.value))}
                    className="w-16 bg-white text-xs border border-stone-200 rounded-xl px-2 py-2 font-bold text-center focus:outline-none"
                  />
                  <input
                    type="text"
                    placeholder="Unit (g, tbsp, pcs)"
                    value={ing.unit}
                    onChange={e => updateIngredient(ing.id, 'unit', e.target.value)}
                    className="w-24 bg-white text-xs border border-stone-200 rounded-xl px-2 py-2 text-stone-700 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => removeIngredient(ing.id)}
                    className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-stone-200 transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </section>

          {/* Dynamic Preparation Steps Builder */}
          <section className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div>
                <h2 className="font-serif text-lg font-bold text-stone-900">Preparation Steps</h2>
                <p className="text-xs text-stone-500">Order steps logically and add timer durations</p>
              </div>
              <button
                type="button"
                onClick={addStep}
                className="flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-50 hover:bg-amber-100 px-3 py-1.5 rounded-xl transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Step</span>
              </button>
            </div>

            <div className="space-y-4">
              {steps.map((st, idx) => (
                <div key={st.id} className="bg-stone-50 p-4 rounded-2xl border border-stone-200 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-amber-900 bg-amber-100 px-2.5 py-1 rounded-full">
                      Step {st.stepNumber}
                    </span>
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => moveStep(idx, 'up')}
                        disabled={idx === 0}
                        className="p-1 text-stone-500 hover:text-stone-900 disabled:opacity-30"
                      >
                        <MoveUp className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => moveStep(idx, 'down')}
                        disabled={idx === steps.length - 1}
                        className="p-1 text-stone-500 hover:text-stone-900 disabled:opacity-30"
                      >
                        <MoveDown className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => removeStep(st.id)}
                        className="p-1 text-stone-400 hover:text-rose-600 ml-2"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <input
                    type="text"
                    placeholder="Step Title (e.g., Sear Mushrooms)"
                    value={st.title || ''}
                    onChange={e => updateStep(st.id, 'title', e.target.value)}
                    className="w-full bg-white text-xs font-bold border border-stone-200 rounded-xl px-3 py-2 focus:outline-none"
                  />

                  <textarea
                    rows={2}
                    placeholder="Step instructions..."
                    value={st.instruction}
                    onChange={e => updateStep(st.id, 'instruction', e.target.value)}
                    className="w-full bg-white text-xs border border-stone-200 rounded-xl p-3 focus:outline-none resize-none font-normal"
                  />

                  <div className="flex gap-2">
                    <input
                      type="number"
                      placeholder="Timer (mins)"
                      value={st.timerMinutes || ''}
                      onChange={e => updateStep(st.id, 'timerMinutes', Number(e.target.value) || undefined)}
                      className="w-32 bg-white text-xs border border-stone-200 rounded-xl px-3 py-1.5 focus:outline-none font-mono"
                    />
                    <input
                      type="text"
                      placeholder="Chef tip (optional)"
                      value={st.tip || ''}
                      onChange={e => updateStep(st.id, 'tip', e.target.value)}
                      className="flex-1 bg-white text-xs border border-stone-200 rounded-xl px-3 py-1.5 focus:outline-none"
                    />
                  </div>
                </div>
              ))}
            </div>
          </section>

          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => setStepPage(1)}
              className="flex items-center gap-1.5 text-stone-700 bg-stone-100 font-bold text-xs px-5 py-3 rounded-2xl hover:bg-stone-200"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              onClick={() => setStepPage(3)}
              className="flex items-center gap-2 bg-stone-900 text-white font-bold text-xs px-6 py-3 rounded-2xl hover:bg-amber-800 transition-colors shadow-md"
            >
              <span>Next: Tags & Publish</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: TAGS & PUBLISH */}
      {stepPage === 3 && (
        <section className="bg-white p-6 rounded-3xl border border-stone-200/80 shadow-sm space-y-6 animate-in fade-in duration-200">
          <div className="space-y-3">
            <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
              Cuisine & Category
            </label>
            <div className="grid grid-cols-2 gap-3">
              <select
                value={cuisine}
                onChange={e => setCuisine(e.target.value as Cuisine)}
                className="bg-stone-50 border border-stone-200 text-stone-900 text-xs font-bold rounded-xl px-3 py-2.5 focus:outline-none"
              >
                {cuisinesList.map(c => (
                  <option key={c} value={c}>{c} Cuisine</option>
                ))}
              </select>

              <select
                value={category}
                onChange={e => setCategory(e.target.value as Category)}
                className="bg-stone-50 border border-stone-200 text-stone-900 text-xs font-bold rounded-xl px-3 py-2.5 focus:outline-none"
              >
                {categoriesList.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
              Dietary Tags
            </label>
            <div className="flex flex-wrap gap-2">
              {dietaryList.map(tag => {
                const active = dietaryTags.includes(tag);
                return (
                  <button
                    type="button"
                    key={tag}
                    onClick={() => toggleDietaryTag(tag)}
                    className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      active
                        ? 'bg-amber-800 text-white'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {tag}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-stone-700 uppercase tracking-wider">
              Chef Advice & Substitutions (One per line)
            </label>
            <textarea
              rows={3}
              value={tipsInput}
              onChange={e => setTipsInput(e.target.value)}
              placeholder="e.g. Reserve 1/2 cup pasta water before draining&#10;Substitute white wine with lemon juice"
              className="w-full bg-stone-50 border border-stone-200 text-stone-900 text-xs rounded-xl p-3 focus:outline-none resize-none font-medium"
            />
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-stone-100">
            <button
              type="button"
              onClick={() => setStepPage(2)}
              className="flex items-center gap-1.5 text-stone-700 bg-stone-100 font-bold text-xs px-5 py-3 rounded-2xl hover:bg-stone-200"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>

            <button
              type="button"
              onClick={handlePublish}
              className="flex items-center gap-2 bg-amber-800 text-white font-bold text-xs px-8 py-3.5 rounded-2xl hover:bg-amber-900 transition-colors shadow-lg shadow-amber-800/20"
            >
              <Sparkles className="w-4 h-4" />
              <span>Publish Recipe Now</span>
            </button>
          </div>
        </section>
      )}

      {/* Preset Image Picker Modal */}
      {showImagePicker && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-stone-100 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <h3 className="font-serif text-lg font-bold text-stone-900">Select Food Photography</h3>
              <button onClick={() => setShowImagePicker(false)} className="p-1 text-stone-400 hover:text-stone-800">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-3 my-4">
              {PRESET_FOOD_IMAGES.map((item, idx) => (
                <div
                  key={idx}
                  onClick={() => {
                    setCoverImage(item.url);
                    setShowImagePicker(false);
                  }}
                  className="group relative aspect-square rounded-2xl overflow-hidden cursor-pointer border border-stone-200 hover:ring-4 hover:ring-amber-700/50 transition-all"
                >
                  <img src={item.url} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent flex items-end p-2.5">
                    <span className="text-xs font-bold text-white">{item.name}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Preview Modal */}
      {showPreviewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-2xl bg-[#FAF8F5] rounded-3xl p-6 shadow-2xl border border-stone-100 max-h-[90vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-stone-200 pb-3">
              <span className="text-xs font-bold uppercase tracking-wider text-amber-800">Recipe Preview</span>
              <button onClick={() => setShowPreviewModal(false)} className="p-1 text-stone-500 hover:text-stone-900">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="aspect-[16/9] rounded-2xl overflow-hidden bg-stone-200">
              <img src={coverImage} alt="Preview" className="w-full h-full object-cover" />
            </div>

            <h2 className="font-serif text-2xl font-bold text-stone-900">{title || 'Untitled Recipe'}</h2>
            <p className="text-xs text-stone-600">{description || 'No description provided.'}</p>

            <div className="bg-white p-4 rounded-2xl border border-stone-200">
              <p className="text-xs font-bold text-stone-900 mb-2">Ingredients ({ingredients.length})</p>
              <ul className="list-disc list-inside text-xs text-stone-700 space-y-1">
                {ingredients.map(i => (
                  <li key={i.id}>{i.amount} {i.unit} {i.name}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
