import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Search, SlidersHorizontal, Star, Clock, UserPlus, UserCheck, X, Sparkles, Flame, ChefHat } from 'lucide-react';
import { Cuisine, DietaryTag, Difficulty } from '../../types';

export const SearchDiscover: React.FC = () => {
  const {
    recipes,
    users,
    currentUser,
    openRecipeDetail,
    toggleFollowUser,
    searchQuery,
    setSearchQuery,
    selectedFilterCuisine,
    setSelectedFilterCuisine,
    selectedFilterDietary,
    setSelectedFilterDietary
  } = useApp();

  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty | 'All'>('All');
  const [maxTotalTime, setMaxTotalTime] = useState<number | 'Any'>('Any');
  const [minRating, setMinRating] = useState<number | 'Any'>('Any');
  const [showFilterModal, setShowFilterModal] = useState(false);

  // Suggested Category Pills
  const categories = [
    { name: 'Pasta & Noodles', image: 'https://images.unsplash.com/photo-1621996346565-e3d5d6281232?w=400&q=80', tag: 'Pasta' },
    { name: 'Breakfast & Brunch', image: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=400&q=80', tag: 'Breakfast' },
    { name: 'Fresh Bowls & Salads', image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&q=80', tag: 'Salad' },
    { name: 'Baking & Desserts', image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=400&q=80', tag: 'Dessert' },
    { name: 'Street Food & Tacos', image: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=400&q=80', tag: 'Main Course' }
  ];

  const cuisinesList: Cuisine[] = ['Italian', 'Japanese', 'Mexican', 'Mediterranean', 'French', 'Nordic', 'Thai', 'Indian', 'Modern American'];
  const dietaryList: DietaryTag[] = ['Vegetarian', 'Vegan', 'Gluten-Free', 'Dairy-Free', 'Low-Carb', 'Nut-Free', 'Keto'];

  // Search Logic
  const query = searchQuery.toLowerCase().trim();

  const searchResults = recipes.filter(r => {
    // Text search matching: title, ingredient, creator, cuisine, dietary tag
    const matchesQuery = !query || (
      r.title.toLowerCase().includes(query) ||
      r.description.toLowerCase().includes(query) ||
      r.creatorName.toLowerCase().includes(query) ||
      r.creatorUsername.toLowerCase().includes(query) ||
      r.cuisine.toLowerCase().includes(query) ||
      r.category.toLowerCase().includes(query) ||
      r.ingredients.some(ing => ing.name.toLowerCase().includes(query)) ||
      r.dietaryTags.some(tag => tag.toLowerCase().includes(query))
    );

    const matchesCuisine = !selectedFilterCuisine || r.cuisine === selectedFilterCuisine;
    const matchesDietary = !selectedFilterDietary || r.dietaryTags.includes(selectedFilterDietary as DietaryTag);
    const matchesDifficulty = selectedDifficulty === 'All' || r.difficulty === selectedDifficulty;
    const matchesTime = maxTotalTime === 'Any' || r.totalTimeMinutes <= Number(maxTotalTime);
    const matchesRating = minRating === 'Any' || r.averageRating >= Number(minRating);

    return matchesQuery && matchesCuisine && matchesDietary && matchesDifficulty && matchesTime && matchesRating;
  });

  const activeFilterCount = (selectedFilterCuisine ? 1 : 0) +
    (selectedFilterDietary ? 1 : 0) +
    (selectedDifficulty !== 'All' ? 1 : 0) +
    (maxTotalTime !== 'Any' ? 1 : 0) +
    (minRating !== 'Any' ? 1 : 0);

  const clearAllFilters = () => {
    setSelectedFilterCuisine(null);
    setSelectedFilterDietary(null);
    setSelectedDifficulty('All');
    setMaxTotalTime('Any');
    setMinRating('Any');
    setSearchQuery('');
  };

  return (
    <div className="space-y-6 pb-16">
      {/* Search Input Bar */}
      <div className="relative flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-stone-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search recipes, ingredients, creators, cuisines..."
            className="w-full bg-white text-stone-900 placeholder-stone-400 text-sm rounded-2xl pl-11 pr-10 py-3 border border-stone-200/80 shadow-sm focus:outline-none focus:ring-2 focus:ring-amber-800/30 font-medium"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-stone-400 hover:text-stone-800"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Trigger Button */}
        <button
          onClick={() => setShowFilterModal(true)}
          className={`flex items-center gap-1.5 px-4 py-3 rounded-2xl border text-xs font-bold transition-all shadow-sm ${
            activeFilterCount > 0
              ? 'bg-amber-800 text-white border-amber-800'
              : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span className="hidden sm:inline">Filters</span>
          {activeFilterCount > 0 && (
            <span className="bg-white text-amber-900 w-4 h-4 rounded-full text-[10px] font-extrabold flex items-center justify-center">
              {activeFilterCount}
            </span>
          )}
        </button>
      </div>

      {/* Quick Filter Tags Row */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
        {selectedFilterCuisine && (
          <span className="flex items-center gap-1 bg-amber-100 text-amber-900 text-xs font-semibold px-3 py-1.5 rounded-full border border-amber-200">
            Cuisine: {selectedFilterCuisine}
            <X className="w-3.5 h-3.5 cursor-pointer" onClick={() => setSelectedFilterCuisine(null)} />
          </span>
        )}
        {selectedFilterDietary && (
          <span className="flex items-center gap-1 bg-amber-100 text-amber-900 text-xs font-semibold px-3 py-1.5 rounded-full border border-amber-200">
            Diet: {selectedFilterDietary}
            <X className="w-3.5 h-3.5 cursor-pointer" onClick={() => setSelectedFilterDietary(null)} />
          </span>
        )}
        {activeFilterCount > 0 && (
          <button
            onClick={clearAllFilters}
            className="text-xs font-semibold text-rose-700 hover:underline px-2"
          >
            Clear all
          </button>
        )}
      </div>

      {/* Suggested Categories Banner (Shown when query is empty) */}
      {!query && activeFilterCount === 0 && (
        <section className="space-y-3">
          <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-amber-700" />
            <span>Discover Categories</span>
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {categories.map((cat, idx) => (
              <div
                key={idx}
                onClick={() => setSearchQuery(cat.tag)}
                className="relative h-24 rounded-2xl overflow-hidden cursor-pointer group shadow-sm"
              >
                <img
                  src={cat.image}
                  alt={cat.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent flex items-end p-3">
                  <span className="text-xs font-bold text-white leading-tight drop-shadow-sm">
                    {cat.name}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Trending Creators Carousel */}
      {!query && (
        <section className="space-y-3 pt-2">
          <div className="flex items-center justify-between">
            <h3 className="font-serif text-lg font-bold text-stone-900 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-amber-700" />
              <span>Trending Creators</span>
            </h3>
          </div>

          <div className="flex gap-3 overflow-x-auto pb-2 scrollbar-none">
            {users.filter(u => u.id !== currentUser.id).map(user => {
              const isFollowing = currentUser.followingUserIds.includes(user.id);
              return (
                <div
                  key={user.id}
                  className="bg-white rounded-2xl p-3.5 border border-stone-200/80 shadow-sm flex flex-col items-center text-center min-w-[150px] shrink-0"
                >
                  <img
                    src={user.avatar}
                    alt={user.name}
                    className="w-14 h-14 rounded-full object-cover ring-2 ring-amber-600/30 mb-2"
                  />
                  <h4 className="text-xs font-bold text-stone-900 truncate w-full">{user.name}</h4>
                  <p className="text-[10px] text-stone-500 truncate w-full">@{user.username}</p>
                  <p className="text-[10px] font-medium text-amber-800 mt-1">
                    {user.followersCount.toLocaleString()} followers
                  </p>

                  <button
                    onClick={() => toggleFollowUser(user.id)}
                    className={`w-full mt-2.5 py-1.5 px-3 rounded-xl text-xs font-semibold transition-colors flex items-center justify-center gap-1 ${
                      isFollowing
                        ? 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                        : 'bg-stone-900 text-white hover:bg-amber-800'
                    }`}
                  >
                    {isFollowing ? (
                      <>
                        <UserCheck className="w-3 h-3 text-amber-700" />
                        <span>Following</span>
                      </>
                    ) : (
                      <>
                        <UserPlus className="w-3 h-3" />
                        <span>Follow</span>
                      </>
                    )}
                  </button>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Visual Recipe Grid (Instagram Style) */}
      <section className="space-y-3 pt-2">
        <div className="flex items-center justify-between">
          <h3 className="font-serif text-lg font-bold text-stone-900">
            {query || activeFilterCount > 0 ? `Results (${searchResults.length})` : 'Popular Recipes'}
          </h3>
        </div>

        {searchResults.length === 0 ? (
          <div className="bg-white rounded-3xl p-10 text-center border border-stone-200">
            <Search className="w-10 h-10 text-stone-300 mx-auto mb-2" />
            <h4 className="font-serif text-base font-bold text-stone-800">No matching recipes</h4>
            <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
              Try searching for a different ingredient or clearing filters.
            </p>
            <button
              onClick={clearAllFilters}
              className="mt-3 text-xs font-semibold text-amber-800 underline"
            >
              Reset Search & Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3.5">
            {searchResults.map(recipe => (
              <div
                key={recipe.id}
                onClick={() => openRecipeDetail(recipe.id)}
                className="group relative aspect-square rounded-2xl overflow-hidden bg-stone-100 cursor-pointer shadow-sm border border-stone-200/60"
              >
                <img
                  src={recipe.coverImage}
                  alt={recipe.title}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/90 via-stone-950/20 to-transparent p-3 flex flex-col justify-end">
                  <p className="text-xs font-bold text-white line-clamp-1 group-hover:text-amber-300 transition-colors">
                    {recipe.title}
                  </p>
                  <p className="text-[10px] text-stone-300 truncate">@{recipe.creatorUsername}</p>

                  <div className="flex items-center justify-between mt-1 text-[10px] text-stone-200 font-medium">
                    <span className="flex items-center gap-0.5">
                      <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                      {recipe.averageRating.toFixed(1)}
                    </span>
                    <span className="flex items-center gap-0.5">
                      <Clock className="w-3 h-3 text-stone-300" />
                      {recipe.totalTimeMinutes}m
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* Filter Options Modal */}
      {showFilterModal && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-stone-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-3xl p-6 shadow-2xl border border-stone-100 max-h-[90vh] overflow-y-auto animate-in slide-in-from-bottom-4 duration-250 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-stone-100">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-amber-800" />
                <h3 className="font-serif text-lg font-bold text-stone-900">Filter Recipes</h3>
              </div>
              <button
                onClick={() => setShowFilterModal(false)}
                className="p-1.5 text-stone-400 hover:text-stone-800 rounded-full hover:bg-stone-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Cuisine Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                Cuisine
              </label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSelectedFilterCuisine(null)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    !selectedFilterCuisine ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-700'
                  }`}
                >
                  All
                </button>
                {cuisinesList.map(c => (
                  <button
                    key={c}
                    onClick={() => setSelectedFilterCuisine(selectedFilterCuisine === c ? null : c)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      selectedFilterCuisine === c ? 'bg-amber-800 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>

            {/* Dietary Selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                Dietary Preferences
              </label>
              <div className="flex flex-wrap gap-1.5">
                <button
                  onClick={() => setSelectedFilterDietary(null)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    !selectedFilterDietary ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-700'
                  }`}
                >
                  All
                </button>
                {dietaryList.map(d => (
                  <button
                    key={d}
                    onClick={() => setSelectedFilterDietary(selectedFilterDietary === d ? null : d)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      selectedFilterDietary === d ? 'bg-amber-800 text-white' : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            {/* Preparation Time Slider */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                Max Total Cook Time: {maxTotalTime === 'Any' ? 'Any' : `${maxTotalTime} mins`}
              </label>
              <div className="flex gap-2">
                {[15, 30, 45, 60, 'Any'].map(t => (
                  <button
                    key={t}
                    onClick={() => setMaxTotalTime(t as any)}
                    className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                      maxTotalTime === t ? 'bg-amber-800 text-white' : 'bg-stone-100 text-stone-700'
                    }`}
                  >
                    {t === 'Any' ? 'Any' : `<${t}m`}
                  </button>
                ))}
              </div>
            </div>

            {/* Difficulty */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-stone-500 uppercase tracking-wider">
                Difficulty
              </label>
              <div className="flex gap-2">
                {['All', 'Easy', 'Medium', 'Hard', 'Chef'].map(diff => (
                  <button
                    key={diff}
                    onClick={() => setSelectedDifficulty(diff as any)}
                    className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                      selectedDifficulty === diff ? 'bg-amber-800 text-white' : 'bg-stone-100 text-stone-700'
                    }`}
                  >
                    {diff}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3 pt-3 border-t border-stone-100">
              <button
                type="button"
                onClick={clearAllFilters}
                className="flex-1 py-3 text-xs font-semibold text-stone-600 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors"
              >
                Reset
              </button>
              <button
                type="button"
                onClick={() => setShowFilterModal(false)}
                className="flex-1 py-3 text-xs font-semibold text-white bg-amber-800 hover:bg-amber-900 rounded-xl transition-colors shadow-sm"
              >
                Show Results
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
