import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  ArrowLeft,
  Heart,
  Bookmark,
  Share2,
  Clock,
  ChefHat,
  Users,
  Plus,
  Minus,
  CheckCircle2,
  Timer,
  Star,
  MessageSquare,
  UserPlus,
  UserCheck,
  Send,
  Flag,
  Sparkles,
  AlertCircle
} from 'lucide-react';

export const RecipeDetail: React.FC = () => {
  const {
    selectedRecipeId,
    closeRecipeDetail,
    recipes,
    currentUser,
    toggleLikeRecipe,
    setSaveCollectionModalRecipeId,
    toggleFollowUser,
    setShareModalRecipe,
    setReportModalItem,
    addRating,
    addComment,
    toggleLikeComment,
    startCookingTimer,
    openRecipeDetail
  } = useApp();

  const recipe = recipes.find(r => r.id === selectedRecipeId);

  // Servings interactive scaler
  const [servings, setServings] = useState(recipe ? recipe.servings : 2);
  // Checked ingredients state
  const [checkedIngredients, setCheckedIngredients] = useState<{ [id: string]: boolean }>({});
  // Rating widget state
  const [userScore, setUserScore] = useState(5);
  const [ratingComment, setRatingComment] = useState('');
  // New comment text
  const [newCommentText, setNewCommentText] = useState('');
  // Reply active input state
  const [replyParentId, setReplyParentId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  if (!recipe) return null;

  const isOwnRecipe = recipe.creatorId === currentUser.id;
  const scaleFactor = servings / recipe.servings;

  const handleServingChange = (delta: number) => {
    setServings(prev => Math.max(1, Math.min(20, prev + delta)));
  };

  const toggleCheckIngredient = (id: string) => {
    setCheckedIngredients(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const handleRatingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addRating(recipe.id, userScore, ratingComment.trim() || undefined);
    setRatingComment('');
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) return;
    addComment(recipe.id, newCommentText.trim());
    setNewCommentText('');
  };

  const handleReplySubmit = (e: React.FormEvent, parentId: string) => {
    e.preventDefault();
    if (!replyText.trim()) return;
    addComment(recipe.id, replyText.trim(), parentId);
    setReplyText('');
    setReplyParentId(null);
  };

  // Similar recipes
  const similarRecipes = recipes
    .filter(r => r.id !== recipe.id && (r.cuisine === recipe.cuisine || r.category === recipe.category))
    .slice(0, 3);

  return (
    <div className="bg-[#FAF8F5] min-h-screen pb-24 animate-in fade-in duration-200">
      {/* Sticky Back & Share Bar */}
      <div className="sticky top-0 z-40 bg-[#FAF8F5]/90 backdrop-blur-md px-4 py-3 border-b border-stone-200/80 flex items-center justify-between">
        <button
          onClick={closeRecipeDetail}
          className="flex items-center gap-1.5 text-xs font-bold text-stone-800 hover:text-stone-950 bg-stone-100 hover:bg-stone-200 px-3 py-1.5 rounded-full transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back</span>
        </button>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShareModalRecipe(recipe)}
            className="p-2 text-stone-700 hover:text-stone-950 bg-stone-100 hover:bg-stone-200 rounded-full transition-colors"
            aria-label="Share"
          >
            <Share2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => setSaveCollectionModalRecipeId(recipe.id)}
            className={`p-2 rounded-full transition-colors ${
              recipe.isSaved
                ? 'bg-amber-100 text-amber-900'
                : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
            }`}
            aria-label="Save"
          >
            <Bookmark className={`w-4 h-4 ${recipe.isSaved ? 'fill-amber-800' : ''}`} />
          </button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto space-y-6 px-4 pt-4">
        {/* Large Cover Image Header */}
        <div className="relative aspect-[16/10] sm:aspect-[21/10] w-full rounded-3xl overflow-hidden shadow-lg border border-stone-200/80">
          <img
            src={recipe.coverImage}
            alt={recipe.title}
            className="w-full h-full object-cover"
          />

          {/* Cuisine & Dietary Pills Overlay */}
          <div className="absolute top-4 left-4 flex flex-wrap gap-2">
            <span className="bg-stone-900/85 backdrop-blur-md text-white text-xs font-bold px-3 py-1.5 rounded-full uppercase tracking-wider">
              {recipe.cuisine}
            </span>
            {recipe.dietaryTags.map(tag => (
              <span
                key={tag}
                className="bg-amber-900/85 backdrop-blur-md text-amber-100 text-xs font-semibold px-3 py-1.5 rounded-full"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Title & Short Description */}
        <div>
          <h1 className="font-serif text-2xl sm:text-4xl font-black text-stone-900 leading-tight">
            {recipe.title}
          </h1>
          <p className="text-sm text-stone-600 mt-2 leading-relaxed font-normal">
            {recipe.description}
          </p>
        </div>

        {/* Creator Info Card */}
        <div className="flex items-center justify-between bg-white p-4 rounded-2xl border border-stone-200/80 shadow-sm">
          <div className="flex items-center gap-3 min-w-0">
            <img
              src={recipe.creatorAvatar}
              alt={recipe.creatorName}
              className="w-12 h-12 rounded-full object-cover ring-2 ring-amber-700/30 shrink-0"
            />
            <div className="min-w-0">
              <p className="text-xs font-semibold text-stone-400 uppercase tracking-wider">Created By</p>
              <h3 className="text-sm font-bold text-stone-900 truncate">{recipe.creatorName}</h3>
              <p className="text-xs text-stone-500 truncate">@{recipe.creatorUsername}</p>
            </div>
          </div>

          {!isOwnRecipe && (
            <button
              onClick={() => toggleFollowUser(recipe.creatorId)}
              className={`flex items-center gap-1.5 text-xs font-bold px-4 py-2 rounded-full transition-all shadow-sm ${
                recipe.creatorIsFollowed
                  ? 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                  : 'bg-amber-800 text-white hover:bg-amber-900'
              }`}
            >
              {recipe.creatorIsFollowed ? (
                <>
                  <UserCheck className="w-3.5 h-3.5 text-amber-700" />
                  <span>Following</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-3.5 h-3.5" />
                  <span>Follow</span>
                </>
              )}
            </button>
          )}
        </div>

        {/* Key Metrics Bar */}
        <div className="grid grid-cols-4 gap-2 bg-white p-4 rounded-2xl border border-stone-200/80 shadow-sm text-center">
          <div>
            <Clock className="w-4 h-4 text-amber-700 mx-auto mb-1" />
            <p className="text-[10px] uppercase tracking-wider font-semibold text-stone-400">Prep</p>
            <p className="text-xs font-bold text-stone-900">{recipe.prepTimeMinutes}m</p>
          </div>
          <div>
            <Clock className="w-4 h-4 text-amber-700 mx-auto mb-1" />
            <p className="text-[10px] uppercase tracking-wider font-semibold text-stone-400">Cook</p>
            <p className="text-xs font-bold text-stone-900">{recipe.cookTimeMinutes}m</p>
          </div>
          <div>
            <ChefHat className="w-4 h-4 text-amber-700 mx-auto mb-1" />
            <p className="text-[10px] uppercase tracking-wider font-semibold text-stone-400">Difficulty</p>
            <p className="text-xs font-bold text-stone-900">{recipe.difficulty}</p>
          </div>
          <div>
            <Star className="w-4 h-4 text-amber-500 fill-amber-500 mx-auto mb-1" />
            <p className="text-[10px] uppercase tracking-wider font-semibold text-stone-400">Rating</p>
            <p className="text-xs font-bold text-stone-900">{recipe.averageRating.toFixed(1)} ({recipe.ratingCount})</p>
          </div>
        </div>

        {/* Interactive Servings Scaler & Ingredients List */}
        <section className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200/80 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-stone-100 pb-4">
            <div>
              <h2 className="font-serif text-lg font-bold text-stone-900">Ingredients</h2>
              <p className="text-xs text-stone-500">Tap items to check off as you prepare</p>
            </div>

            {/* Interactive Servings Controller */}
            <div className="flex items-center gap-3 bg-stone-100 px-3 py-1.5 rounded-2xl border border-stone-200">
              <Users className="w-4 h-4 text-stone-500" />
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleServingChange(-1)}
                  disabled={servings <= 1}
                  className="p-1 rounded-lg bg-white text-stone-700 hover:bg-stone-200 disabled:opacity-40 transition-colors"
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="text-xs font-extrabold text-stone-900 min-w-[50px] text-center">
                  {servings} {servings === 1 ? 'serving' : 'servings'}
                </span>
                <button
                  onClick={() => handleServingChange(1)}
                  className="p-1 rounded-lg bg-white text-stone-700 hover:bg-stone-200 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          <div className="divide-y divide-stone-100">
            {recipe.ingredients.map(ing => {
              const scaledAmount = (ing.amount * scaleFactor).toFixed(ing.amount * scaleFactor % 1 === 0 ? 0 : 1);
              const isChecked = !!checkedIngredients[ing.id];

              return (
                <div
                  key={ing.id}
                  onClick={() => toggleCheckIngredient(ing.id)}
                  className={`flex items-center justify-between py-3 px-2 rounded-xl cursor-pointer transition-colors ${
                    isChecked ? 'bg-stone-50 opacity-60' : 'hover:bg-stone-50'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors ${
                      isChecked ? 'bg-amber-800 border-amber-800 text-white' : 'border-stone-300'
                    }`}>
                      {isChecked && <CheckCircle2 className="w-4 h-4" />}
                    </div>
                    <span className={`text-xs font-medium text-stone-900 ${isChecked ? 'line-through text-stone-400' : ''}`}>
                      {ing.name}
                    </span>
                  </div>

                  <span className="text-xs font-bold text-amber-900 font-mono">
                    {scaledAmount} {ing.unit}
                  </span>
                </div>
              );
            })}
          </div>
        </section>

        {/* Numbered Preparation Steps */}
        <section className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200/80 shadow-sm space-y-4">
          <h2 className="font-serif text-lg font-bold text-stone-900 border-b border-stone-100 pb-3">
            Preparation Steps
          </h2>

          <div className="space-y-4">
            {recipe.steps.map(step => (
              <div
                key={step.id}
                className="flex gap-4 p-4 rounded-2xl bg-stone-50/70 border border-stone-200/60"
              >
                <div className="w-8 h-8 rounded-full bg-amber-800 text-white font-serif font-bold text-sm flex items-center justify-center shrink-0 shadow-sm">
                  {step.stepNumber}
                </div>

                <div className="space-y-2 flex-1 min-w-0">
                  {step.title && (
                    <h3 className="text-sm font-bold text-stone-900">{step.title}</h3>
                  )}
                  <p className="text-xs text-stone-700 leading-relaxed font-normal">
                    {step.instruction}
                  </p>

                  {step.tip && (
                    <div className="flex items-start gap-2 bg-amber-50 p-2.5 rounded-xl border border-amber-200/60 text-amber-900 text-xs">
                      <Sparkles className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                      <p><span className="font-bold">Chef Tip:</span> {step.tip}</p>
                    </div>
                  )}

                  {step.timerMinutes && (
                    <button
                      onClick={() => startCookingTimer(step.title || `Step ${step.stepNumber}`, step.timerMinutes!, recipe.title)}
                      className="mt-2 flex items-center gap-1.5 bg-amber-100 hover:bg-amber-200 text-amber-900 text-xs font-bold px-3 py-1.5 rounded-xl transition-colors w-fit"
                    >
                      <Timer className="w-3.5 h-3.5 text-amber-800" />
                      <span>Start {step.timerMinutes} Min Step Timer</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Tips, Substitutions & Allergen Info */}
        {(recipe.tipsAndSubstitutions.length > 0 || recipe.allergenInfo.length > 0) && (
          <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {recipe.tipsAndSubstitutions.length > 0 && (
              <div className="bg-amber-50/80 p-5 rounded-3xl border border-amber-200/80">
                <h3 className="font-serif text-sm font-bold text-amber-950 flex items-center gap-1.5 mb-2">
                  <Sparkles className="w-4 h-4 text-amber-800" />
                  <span>Chef Advice & Substitutions</span>
                </h3>
                <ul className="list-disc list-inside space-y-1 text-xs text-amber-900 font-medium">
                  {recipe.tipsAndSubstitutions.map((tip, idx) => (
                    <li key={idx}>{tip}</li>
                  ))}
                </ul>
              </div>
            )}

            {recipe.allergenInfo.length > 0 && (
              <div className="bg-stone-100 p-5 rounded-3xl border border-stone-200">
                <h3 className="font-serif text-sm font-bold text-stone-900 flex items-center gap-1.5 mb-2">
                  <AlertCircle className="w-4 h-4 text-stone-600" />
                  <span>Allergen Notice</span>
                </h3>
                <div className="flex flex-wrap gap-1.5">
                  {recipe.allergenInfo.map((all, idx) => (
                    <span key={idx} className="bg-white text-stone-700 text-[11px] font-semibold px-2.5 py-1 rounded-full border border-stone-200">
                      {all}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}

        {/* Ratings & Rating Histogram Section */}
        <section className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200/80 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-stone-100 pb-3">
            <h2 className="font-serif text-lg font-bold text-stone-900">Ratings & Reviews</h2>
            <button
              onClick={() => setReportModalItem({ id: recipe.id, type: 'recipe' })}
              className="text-xs font-medium text-stone-400 hover:text-stone-700 flex items-center gap-1"
            >
              <Flag className="w-3.5 h-3.5" />
              <span>Report</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 items-center">
            {/* Avg score block */}
            <div className="text-center sm:border-r border-stone-100 sm:pr-4">
              <p className="font-serif text-4xl font-black text-amber-800">
                {recipe.averageRating.toFixed(1)}
              </p>
              <div className="flex justify-center gap-1 my-1">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${
                      star <= Math.round(recipe.averageRating)
                        ? 'text-amber-500 fill-amber-500'
                        : 'text-stone-300'
                    }`}
                  />
                ))}
              </div>
              <p className="text-xs text-stone-500 font-medium">Based on {recipe.ratingCount} ratings</p>
            </div>

            {/* Distribution Histogram */}
            <div className="sm:col-span-2 space-y-1.5">
              {[5, 4, 3, 2, 1].map(score => {
                const count = recipe.ratingDistribution[score] || 0;
                const percentage = recipe.ratingCount > 0 ? (count / recipe.ratingCount) * 100 : 0;
                return (
                  <div key={score} className="flex items-center gap-2 text-xs font-semibold text-stone-600">
                    <span className="w-3">{score}★</span>
                    <div className="flex-1 bg-stone-100 h-2 rounded-full overflow-hidden">
                      <div className="bg-amber-500 h-full rounded-full" style={{ width: `${percentage}%` }} />
                    </div>
                    <span className="w-8 text-right text-[11px] text-stone-400">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Leave a Rating Form */}
          <form onSubmit={handleRatingSubmit} className="bg-stone-50 p-4 rounded-2xl border border-stone-200/80 space-y-3">
            <p className="text-xs font-bold text-stone-800">Rate this recipe</p>
            <div className="flex items-center gap-2">
              {[1, 2, 3, 4, 5].map(score => (
                <button
                  type="button"
                  key={score}
                  onClick={() => setUserScore(score)}
                  className="p-1 hover:scale-110 transition-transform"
                >
                  <Star
                    className={`w-6 h-6 ${
                      score <= userScore ? 'text-amber-500 fill-amber-500' : 'text-stone-300'
                    }`}
                  />
                </button>
              ))}
              <span className="text-xs font-bold text-amber-900 ml-2">{userScore} Stars</span>
            </div>

            <input
              type="text"
              placeholder="Write a brief review (optional)..."
              value={ratingComment}
              onChange={e => setRatingComment(e.target.value)}
              className="w-full bg-white text-xs border border-stone-200 rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 focus:ring-amber-800/30 font-medium"
            />

            <button
              type="submit"
              className="bg-amber-800 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-amber-900 transition-colors shadow-sm"
            >
              Submit Rating
            </button>
          </form>
        </section>

        {/* Comments & Discussion */}
        <section className="bg-white p-5 sm:p-6 rounded-3xl border border-stone-200/80 shadow-sm space-y-4">
          <h2 className="font-serif text-lg font-bold text-stone-900 border-b border-stone-100 pb-3 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-amber-800" />
            <span>Community Discussion ({recipe.comments.length})</span>
          </h2>

          {/* Post Comment Input */}
          <form onSubmit={handleCommentSubmit} className="flex items-center gap-2">
            <img src={currentUser.avatar} alt={currentUser.name} className="w-8 h-8 rounded-full object-cover shrink-0" />
            <input
              type="text"
              placeholder="Ask a question or share how your cook turned out..."
              value={newCommentText}
              onChange={e => setNewCommentText(e.target.value)}
              className="flex-1 bg-stone-100 text-xs border border-stone-200 rounded-2xl px-3.5 py-2.5 focus:outline-none focus:ring-2 focus:ring-amber-800/30 font-medium"
            />
            <button
              type="submit"
              disabled={!newCommentText.trim()}
              className="bg-stone-900 text-white p-2.5 rounded-2xl hover:bg-amber-800 disabled:opacity-40 transition-colors shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          {/* Comments Thread */}
          <div className="space-y-4 pt-2">
            {recipe.comments.map(cmt => (
              <div key={cmt.id} className="space-y-2">
                <div className="flex items-start gap-3 bg-stone-50/80 p-3.5 rounded-2xl border border-stone-200/60">
                  <img src={cmt.userAvatar} alt={cmt.userName} className="w-8 h-8 rounded-full object-cover shrink-0" />
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-stone-900">{cmt.userName}</span>
                      <span className="text-[10px] text-stone-400">{cmt.createdAt}</span>
                    </div>
                    <p className="text-xs text-stone-700 mt-1 font-normal leading-relaxed">{cmt.text}</p>

                    <div className="flex items-center gap-4 mt-2">
                      <button
                        onClick={() => toggleLikeComment(recipe.id, cmt.id)}
                        className={`flex items-center gap-1 text-[11px] font-semibold transition-colors ${
                          cmt.isLiked ? 'text-rose-600' : 'text-stone-500 hover:text-stone-800'
                        }`}
                      >
                        <Heart className={`w-3.5 h-3.5 ${cmt.isLiked ? 'fill-rose-600' : ''}`} />
                        <span>{cmt.likesCount}</span>
                      </button>

                      <button
                        onClick={() => setReplyParentId(replyParentId === cmt.id ? null : cmt.id)}
                        className="text-[11px] font-semibold text-stone-500 hover:text-stone-800"
                      >
                        Reply
                      </button>
                    </div>
                  </div>
                </div>

                {/* Reply Form */}
                {replyParentId === cmt.id && (
                  <form onSubmit={e => handleReplySubmit(e, cmt.id)} className="flex items-center gap-2 pl-8 pt-1">
                    <input
                      type="text"
                      placeholder={`Reply to ${cmt.userName}...`}
                      value={replyText}
                      onChange={e => setReplyText(e.target.value)}
                      className="flex-1 bg-white text-xs border border-stone-200 rounded-xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-amber-800/30"
                    />
                    <button
                      type="submit"
                      className="bg-amber-800 text-white text-xs font-bold px-3 py-2 rounded-xl hover:bg-amber-900"
                    >
                      Post
                    </button>
                  </form>
                )}

                {/* Nested Replies */}
                {cmt.replies && cmt.replies.map(rep => (
                  <div key={rep.id} className="flex items-start gap-3 pl-8 bg-amber-50/40 p-3 rounded-2xl border border-amber-100">
                    <img src={rep.userAvatar} alt={rep.userName} className="w-7 h-7 rounded-full object-cover shrink-0" />
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-stone-900">{rep.userName}</span>
                        <span className="text-[10px] text-stone-400">{rep.createdAt}</span>
                      </div>
                      <p className="text-xs text-stone-700 mt-0.5">{rep.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </section>

        {/* Similar Recipes Recommendations */}
        {similarRecipes.length > 0 && (
          <section className="space-y-3 pt-4">
            <h2 className="font-serif text-lg font-bold text-stone-900">You Might Also Like</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {similarRecipes.map(rec => (
                <div
                  key={rec.id}
                  onClick={() => openRecipeDetail(rec.id)}
                  className="bg-white rounded-2xl overflow-hidden border border-stone-200 shadow-sm cursor-pointer group hover:shadow-md transition-all"
                >
                  <img
                    src={rec.coverImage}
                    alt={rec.title}
                    className="w-full h-28 object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="p-3">
                    <h4 className="text-xs font-bold text-stone-900 truncate group-hover:text-amber-800">
                      {rec.title}
                    </h4>
                    <p className="text-[10px] text-stone-500 mt-0.5">⏱ {rec.totalTimeMinutes}m • ⭐ {rec.averageRating}</p>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
};
