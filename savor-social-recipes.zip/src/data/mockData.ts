import { Recipe, User, Collection, Notification } from '../types';

export const CURRENT_USER: User = {
  id: 'usr_me',
  name: 'Alex Rivera',
  username: 'alexcooks',
  avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&q=80',
  bio: 'Home cook obsessed with seasonal produce, sourdough fermentation, and weeknight pasta.',
  location: 'San Francisco, CA',
  followersCount: 342,
  followingCount: 128,
  recipesCount: 4,
  savedCount: 18,
  followingUserIds: ['usr_1', 'usr_3']
};

export const MOCK_USERS: User[] = [
  CURRENT_USER,
  {
    id: 'usr_1',
    name: 'Chef Elena Rostova',
    username: 'elena_rostova',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80',
    bio: 'Executive pastry & pasta chef in NYC. Author of "Flour & Patience". Teaching rustic Mediterranean classics.',
    location: 'New York, NY',
    followersCount: 18900,
    followingCount: 240,
    recipesCount: 48,
    savedCount: 120,
    followingUserIds: []
  },
  {
    id: 'usr_2',
    name: 'Marcus Vance',
    username: 'marcus_flame',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80',
    bio: 'Pitmaster & wood-fired culinary craftsman. Big flavors, smoking secrets, and outdoor cookery.',
    location: 'Austin, TX',
    followersCount: 9400,
    followingCount: 180,
    recipesCount: 32,
    savedCount: 45,
    followingUserIds: ['usr_1']
  },
  {
    id: 'usr_3',
    name: 'Chloe Dubois',
    username: 'chloe_nourish',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&q=80',
    bio: 'Holistic nutritionist & plant-forward recipe creator. Clean ingredients with unapologetic taste.',
    location: 'Paris, France',
    followersCount: 14200,
    followingCount: 310,
    recipesCount: 64,
    savedCount: 210,
    followingUserIds: ['usr_1', 'usr_2']
  },
  {
    id: 'usr_4',
    name: 'Kenji Takahashi',
    username: 'kenji_umami',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&q=80',
    bio: 'Tokyo-born ramen & izakaya traditionalist. Elevating home Japanese cooking step by step.',
    location: 'Tokyo, Japan',
    followersCount: 22100,
    followingCount: 95,
    recipesCount: 52,
    savedCount: 88,
    followingUserIds: ['usr_1']
  }
];

export const INITIAL_COLLECTIONS: Collection[] = [
  {
    id: 'col_1',
    name: 'Favourites',
    description: 'My all-time go-to dishes for special occasions and cozy nights.',
    isPrivate: false,
    recipeIds: ['rec_1', 'rec_3', 'rec_5'],
    coverImage: 'https://images.unsplash.com/photo-1621996346565-e3d5d6281232?w=800&q=80',
    createdAt: '2026-01-10'
  },
  {
    id: 'col_2',
    name: 'Weeknight Dinners',
    description: 'Quick under 30-minute meals with minimal prep and maximum flavor.',
    isPrivate: false,
    recipeIds: ['rec_2', 'rec_4'],
    coverImage: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&q=80',
    createdAt: '2026-02-15'
  },
  {
    id: 'col_3',
    name: 'Desserts & Baking',
    description: 'Decadent sweets, tarts, and weekend sourdough experiments.',
    isPrivate: false,
    recipeIds: ['rec_5'],
    coverImage: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=800&q=80',
    createdAt: '2026-03-01'
  },
  {
    id: 'col_4',
    name: 'Recipes to Try',
    description: 'Bookmarked inspiration from fellow creators to test this month.',
    isPrivate: true,
    recipeIds: ['rec_6', 'rec_7'],
    coverImage: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',
    createdAt: '2026-04-12'
  }
];

export const INITIAL_RECIPES: Recipe[] = [
  {
    id: 'rec_1',
    title: 'Truffle & Wild Mushroom Tagliatelle',
    description: 'Silky handmade egg tagliatelle tossed in brown butter, chanterelles, porcini cream, and freshly shaved black truffle.',
    coverImage: 'https://images.unsplash.com/photo-1621996346565-e3d5d6281232?w=800&q=80',
    prepTimeMinutes: 20,
    cookTimeMinutes: 15,
    totalTimeMinutes: 35,
    difficulty: 'Medium',
    servings: 2,
    cuisine: 'Italian',
    category: 'Pasta',
    dietaryTags: ['Vegetarian'],
    allergenInfo: ['Contains Dairy', 'Contains Gluten', 'Contains Eggs'],
    tipsAndSubstitutions: [
      'If fresh black truffle is unavailable, high quality black truffle butter or white truffle oil works beautifully.',
      'Reserve at least 1/2 cup of starchy pasta water before draining—it binds the emulsion seamlessly.'
    ],
    creatorId: 'usr_1',
    creatorName: 'Chef Elena Rostova',
    creatorUsername: 'elena_rostova',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80',
    creatorIsFollowed: true,
    ingredients: [
      { id: 'i1', name: 'Fresh Tagliatelle', amount: 250, unit: 'g', category: 'Pasta' },
      { id: 'i2', name: 'Mixed Wild Mushrooms (Chanterelles & Cremini)', amount: 300, unit: 'g', category: 'Produce' },
      { id: 'i3', name: 'Unsalted European Butter', amount: 45, unit: 'g', category: 'Dairy' },
      { id: 'i4', name: 'Heavy Whipping Cream', amount: 80, unit: 'ml', category: 'Dairy' },
      { id: 'i5', name: 'Shallot (minced)', amount: 1, unit: 'pc', category: 'Produce' },
      { id: 'i6', name: 'Garlic cloves (thinly sliced)', amount: 2, unit: 'cloves', category: 'Produce' },
      { id: 'i7', name: 'Parmigiano Reggiano (aged 24 mo)', amount: 50, unit: 'g', category: 'Dairy' },
      { id: 'i8', name: 'Fresh Black Truffle (or truffle butter)', amount: 15, unit: 'g', category: 'Specialty' },
      { id: 'i9', name: 'Fresh Thyme Leaves', amount: 1, unit: 'tsp', category: 'Produce' }
    ],
    steps: [
      {
        id: 's1',
        stepNumber: 1,
        title: 'Sear the Mushrooms',
        instruction: 'Heat a large heavy-bottom skillet over high heat. Add a splash of olive oil and sear mushrooms without crowding until golden crisp.',
        timerMinutes: 6,
        tip: 'Do not salt the mushrooms until they develop a golden crust, otherwise they release water and steam.'
      },
      {
        id: 's2',
        stepNumber: 2,
        title: 'Build the Aromatic Base',
        instruction: 'Lower heat to medium. Melt butter in the pan, add minced shallot, garlic, and fresh thyme. Saute for 2 minutes until fragrant and translucent.',
        timerMinutes: 2
      },
      {
        id: 's3',
        stepNumber: 3,
        title: 'Boil Pasta & Emulsify',
        instruction: 'Drop fresh tagliatelle into salted boiling water for 2-3 minutes. Transfer directly to the mushroom skillet along with heavy cream and 1/2 cup pasta water.',
        timerMinutes: 3
      },
      {
        id: 's4',
        stepNumber: 4,
        title: 'Finish & Shave Truffle',
        instruction: 'Remove from heat. Toss vigorously with finely grated Parmigiano Reggiano until glossy. Plate immediately and shave fresh black truffle generously on top.',
        tip: 'Serve in warmed pasta bowls for optimal temperature preservation.'
      }
    ],
    likesCount: 1420,
    isLiked: true,
    savesCount: 512,
    isSaved: true,
    savedInCollectionIds: ['col_1'],
    averageRating: 4.9,
    ratingCount: 128,
    ratingDistribution: { 5: 118, 4: 8, 3: 2, 2: 0, 1: 0 },
    ratings: [
      {
        id: 'r1',
        userId: 'usr_2',
        userName: 'Marcus Vance',
        userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80',
        score: 5,
        comment: 'Absolute restaurant-quality flavor! The pasta water emulsion trick turned it silky smooth.',
        createdAt: '2 days ago'
      }
    ],
    comments: [
      {
        id: 'c1',
        userId: 'usr_3',
        userName: 'Chloe Dubois',
        userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&q=80',
        text: 'Elena, this looks ethereal! Could I substitute cashew cream for a lighter version?',
        createdAt: '3 hours ago',
        likesCount: 14,
        isLiked: false,
        replies: [
          {
            id: 'c1_r1',
            userId: 'usr_1',
            userName: 'Chef Elena Rostova',
            userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80',
            text: 'Merci Chloe! Yes, soaked and blended cashew cream with nutritional yeast creates an amazing velvety texture!',
            createdAt: '2 hours ago',
            likesCount: 9,
            isLiked: true
          }
        ]
      }
    ],
    createdAt: '2026-07-28T14:30:00Z',
    isPublished: true
  },
  {
    id: 'rec_2',
    title: 'Artisanal Sourdough Avocado Toast with Poached Eggs',
    description: 'Thick toasted country sourdough topped with coarse citrus avocado, za\'atar, soft poached egg, and chili oil drizzle.',
    coverImage: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&q=80',
    prepTimeMinutes: 10,
    cookTimeMinutes: 5,
    totalTimeMinutes: 15,
    difficulty: 'Easy',
    servings: 1,
    cuisine: 'Modern American',
    category: 'Breakfast',
    dietaryTags: ['Vegetarian'],
    allergenInfo: ['Contains Eggs', 'Contains Gluten', 'Contains Sesame'],
    tipsAndSubstitutions: [
      'Add 1 tsp of white vinegar to the poaching water to help egg whites set cleanly.',
      'Toast sourdough in cast iron with extra virgin olive oil for maximum crunch.'
    ],
    creatorId: 'usr_3',
    creatorName: 'Chloe Dubois',
    creatorUsername: 'chloe_nourish',
    creatorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&q=80',
    creatorIsFollowed: true,
    ingredients: [
      { id: 'i21', name: 'Artisanal Sourdough Bread', amount: 2, unit: 'thick slices', category: 'Bakery' },
      { id: 'i22', name: 'Ripe Hass Avocado', amount: 1, unit: 'large', category: 'Produce' },
      { id: 'i23', name: 'Fresh Organic Eggs', amount: 2, unit: 'large', category: 'Dairy' },
      { id: 'i24', name: 'Lemon Juice', amount: 1, unit: 'tbsp', category: 'Produce' },
      { id: 'i25', name: 'Za\'atar Seasoning', amount: 1, unit: 'tsp', category: 'Pantry' },
      { id: 'i26', name: 'Crispy Chili Crisp Oil', amount: 1, unit: 'tbsp', category: 'Pantry' },
      { id: 'i27', name: 'Flaky Maldon Sea Salt & Cracked Pepper', amount: 0.5, unit: 'tsp', category: 'Pantry' }
    ],
    steps: [
      {
        id: 's21',
        stepNumber: 1,
        title: 'Prepare Avocado Mash',
        instruction: 'In a small bowl, coarsely mash avocado with lemon juice, pinch of sea salt, and black pepper. Keep it chunky for texture.'
      },
      {
        id: 's22',
        stepNumber: 2,
        title: 'Toast the Sourdough',
        instruction: 'Drizzle sourdough slices with olive oil and toast in skillet or toaster until deep golden brown on edges.'
      },
      {
        id: 's23',
        stepNumber: 3,
        title: 'Poach Eggs',
        instruction: 'Bring a pot of water with vinegar to a gentle simmer. Swirl water to create a vortex and gently drop in cracked eggs. Cook 3 minutes for molten yolk.',
        timerMinutes: 3
      },
      {
        id: 's24',
        stepNumber: 4,
        title: 'Assemble & Garnish',
        instruction: 'Spread avocado generously over toast. Top with poached eggs, sprinkle za\'atar spice blend, and finish with crunchy chili oil.'
      }
    ],
    likesCount: 890,
    isLiked: false,
    savesCount: 340,
    isSaved: true,
    savedInCollectionIds: ['col_2'],
    averageRating: 4.8,
    ratingCount: 84,
    ratingDistribution: { 5: 72, 4: 10, 3: 2, 2: 0, 1: 0 },
    ratings: [],
    comments: [],
    createdAt: '2026-07-29T09:15:00Z',
    isPublished: true
  },
  {
    id: 'rec_3',
    title: 'Seared Sesame Ahi Tuna Poke Bowl',
    description: 'Sustainably caught yellowfin tuna lightly seared in sesame crust, served over steamed sushi rice with avocado, edamame, and yuzu ponzu.',
    coverImage: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80',
    prepTimeMinutes: 15,
    cookTimeMinutes: 5,
    totalTimeMinutes: 20,
    difficulty: 'Medium',
    servings: 2,
    cuisine: 'Japanese',
    category: 'Main Course',
    dietaryTags: ['Dairy-Free', 'Gluten-Free', 'Low-Carb'],
    allergenInfo: ['Contains Fish', 'Contains Sesame', 'Contains Soy'],
    tipsAndSubstitutions: [
      'Ensure you buy sushi-grade Ahi tuna.',
      'Sear only 45 seconds per side to maintain a ruby-red melt-in-your-mouth interior.'
    ],
    creatorId: 'usr_4',
    creatorName: 'Kenji Takahashi',
    creatorUsername: 'kenji_umami',
    creatorAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&q=80',
    creatorIsFollowed: false,
    ingredients: [
      { id: 'i31', name: 'Sushi Grade Yellowfin Tuna Steak', amount: 300, unit: 'g', category: 'Seafood' },
      { id: 'i32', name: 'Mixed Black & White Sesame Seeds', amount: 3, unit: 'tbsp', category: 'Pantry' },
      { id: 'i33', name: 'Short Grain Sushi Rice (cooked)', amount: 2, unit: 'cups', category: 'Pantry' },
      { id: 'i34', name: 'Steamed Edamame Beans', amount: 100, unit: 'g', category: 'Produce' },
      { id: 'i35', name: 'Sliced Cucumber & Radish', amount: 1, unit: 'cup', category: 'Produce' },
      { id: 'i36', name: 'Yuzu Ponzu Dressing', amount: 4, unit: 'tbsp', category: 'Pantry' },
      { id: 'i37', name: 'Sriracha Mayo Drizzle', amount: 2, unit: 'tbsp', category: 'Pantry' }
    ],
    steps: [
      {
        id: 's31',
        stepNumber: 1,
        title: 'Crust the Tuna',
        instruction: 'Pat tuna steak completely dry with paper towels. Press all sides firmly into black and white sesame seeds until coated.'
      },
      {
        id: 's32',
        stepNumber: 2,
        title: 'Flash Sear',
        instruction: 'Heat a cast-iron skillet over maximum heat with sesame oil. Sear tuna 45 seconds on each side. Transfer to cutting board and rest 2 mins before slicing thin.',
        timerMinutes: 1
      },
      {
        id: 's33',
        stepNumber: 3,
        title: 'Bowl Assembly',
        instruction: 'Divide warm sushi rice between two bowls. Arrange sliced tuna, edamame, sliced avocado, cucumber ribbons, and pickled ginger.'
      },
      {
        id: 's34',
        stepNumber: 4,
        title: 'Sauce & Serve',
        instruction: 'Drizzle generously with yuzu ponzu and a zig-zag of spicy mayo. Sprinkle green onions on top.'
      }
    ],
    likesCount: 2150,
    isLiked: false,
    savesCount: 920,
    isSaved: true,
    savedInCollectionIds: ['col_1'],
    averageRating: 5.0,
    ratingCount: 160,
    ratingDistribution: { 5: 155, 4: 5, 3: 0, 2: 0, 1: 0 },
    ratings: [],
    comments: [],
    createdAt: '2026-07-25T11:00:00Z',
    isPublished: true
  },
  {
    id: 'rec_4',
    title: 'Smoky Chipotle Braised Pork Tacos Al Pastor',
    description: 'Slow-braised pork shoulder infused with guajillo, chipotle, and achiote, paired with seared pineapple salsa on handmade corn tortillas.',
    coverImage: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80',
    prepTimeMinutes: 25,
    cookTimeMinutes: 45,
    totalTimeMinutes: 70,
    difficulty: 'Hard',
    servings: 4,
    cuisine: 'Mexican',
    category: 'Main Course',
    dietaryTags: ['Gluten-Free', 'Dairy-Free'],
    allergenInfo: [],
    tipsAndSubstitutions: [
      'Caramelize the pineapple on high heat to get smoky charred edges.',
      'Squeeze fresh lime right before serving to cut through the richness of the braised pork.'
    ],
    creatorId: 'usr_2',
    creatorName: 'Marcus Vance',
    creatorUsername: 'marcus_flame',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80',
    creatorIsFollowed: false,
    ingredients: [
      { id: 'i41', name: 'Boneless Pork Shoulder', amount: 800, unit: 'g', category: 'Meat' },
      { id: 'i42', name: 'Achiote Paste & Guajillo Powder', amount: 2, unit: 'tbsp', category: 'Pantry' },
      { id: 'i43', name: 'Fresh Pineapple Slices', amount: 200, unit: 'g', category: 'Produce' },
      { id: 'i44', name: 'Handmade Corn Tortillas', amount: 8, unit: 'pcs', category: 'Bakery' },
      { id: 'i45', name: 'White Onion & Fresh Cilantro', amount: 1, unit: 'cup', category: 'Produce' },
      { id: 'i46', name: 'Lime Halves', amount: 2, unit: 'pcs', category: 'Produce' }
    ],
    steps: [
      {
        id: 's41',
        stepNumber: 1,
        title: 'Marinate & Braise Pork',
        instruction: 'Cut pork into bite-sized chunks. Rub with achiote paste, orange juice, garlic, and chipotle. Braise on medium heat until tender and crispy on edges.',
        timerMinutes: 35
      },
      {
        id: 's42',
        stepNumber: 2,
        title: 'Char the Pineapple',
        instruction: 'In a dry skillet over high heat, sear pineapple slices until deeply golden charred. Diced into salsa with cilantro and lime.',
        timerMinutes: 5
      },
      {
        id: 's43',
        stepNumber: 3,
        title: 'Warm Tortillas & Build',
        instruction: 'Toast corn tortillas on flat top grill until pliable. Pile high with crispy pastor pork, pineapple salsa, diced white onion, and cilantro.'
      }
    ],
    likesCount: 1680,
    isLiked: true,
    savesCount: 610,
    isSaved: false,
    savedInCollectionIds: [],
    averageRating: 4.9,
    ratingCount: 95,
    ratingDistribution: { 5: 88, 4: 6, 3: 1, 2: 0, 1: 0 },
    ratings: [],
    comments: [],
    createdAt: '2026-07-27T18:20:00Z',
    isPublished: true
  },
  {
    id: 'rec_5',
    title: 'Pistachio & Cardamom Basque Burnt Cheesecake',
    description: 'Ultra-creamy Spanish burnt cheesecake spiked with aromatic green cardamom and drizzled with Sicilian pistachio butter cream.',
    coverImage: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=800&q=80',
    prepTimeMinutes: 20,
    cookTimeMinutes: 40,
    totalTimeMinutes: 60,
    difficulty: 'Medium',
    servings: 8,
    cuisine: 'French',
    category: 'Dessert',
    dietaryTags: ['Vegetarian', 'Gluten-Free'],
    allergenInfo: ['Contains Dairy', 'Contains Eggs', 'Contains Tree Nuts'],
    tipsAndSubstitutions: [
      'Ensure all ingredients (cream cheese, eggs, cream) are at room temperature to avoid lumps.',
      'Bake at high temp (220°C / 430°F) to achieve the iconic dark caramelized crust while keeping the core molten.'
    ],
    creatorId: 'usr_1',
    creatorName: 'Chef Elena Rostova',
    creatorUsername: 'elena_rostova',
    creatorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80',
    creatorIsFollowed: true,
    ingredients: [
      { id: 'i51', name: 'Cream Cheese (softened)', amount: 600, unit: 'g', category: 'Dairy' },
      { id: 'i52', name: 'Castor Sugar', amount: 180, unit: 'g', category: 'Pantry' },
      { id: 'i53', name: 'Large Eggs', amount: 4, unit: 'pcs', category: 'Dairy' },
      { id: 'i54', name: 'Heavy Cream 36%', amount: 300, unit: 'ml', category: 'Dairy' },
      { id: 'i55', name: 'Ground Green Cardamom', amount: 1, unit: 'tsp', category: 'Pantry' },
      { id: 'i56', name: 'Pure Pistachio Cream / Paste', amount: 80, unit: 'g', category: 'Specialty' }
    ],
    steps: [
      {
        id: 's51',
        stepNumber: 1,
        title: 'Cream Cheese Base',
        instruction: 'Beat softened cream cheese and sugar on medium speed for 4 minutes until silky smooth and completely lump-free.',
        timerMinutes: 4
      },
      {
        id: 's52',
        stepNumber: 2,
        title: 'Add Eggs & Flavoring',
        instruction: 'Add eggs one at a time, mixing gently after each addition. Pour in heavy cream, cardamom, and a pinch of salt.'
      },
      {
        id: 's53',
        stepNumber: 3,
        title: 'High Heat Bake',
        instruction: 'Pour into parchment-lined 8-inch springform pan. Bake at 220°C (430°F) for 40 minutes until top is deeply caramelized and center still jiggles.',
        timerMinutes: 40
      },
      {
        id: 's54',
        stepNumber: 4,
        title: 'Chill & Drizzle',
        instruction: 'Cool completely at room temperature for 3 hours. Slice with a hot clean knife and top with warm pistachio butter cream.'
      }
    ],
    likesCount: 3120,
    isLiked: true,
    savesCount: 1420,
    isSaved: true,
    savedInCollectionIds: ['col_1', 'col_3'],
    averageRating: 5.0,
    ratingCount: 210,
    ratingDistribution: { 5: 205, 4: 5, 3: 0, 2: 0, 1: 0 },
    ratings: [],
    comments: [],
    createdAt: '2026-07-20T16:00:00Z',
    isPublished: true
  },
  {
    id: 'rec_6',
    title: 'Golden Coconut Turmeric Tofu Curry',
    description: 'Fragrant golden curry with crispy pan-seared tofu, baby spinach, sweet potatoes, and lemongrass coconut broth.',
    coverImage: 'https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80',
    prepTimeMinutes: 15,
    cookTimeMinutes: 20,
    totalTimeMinutes: 35,
    difficulty: 'Easy',
    servings: 3,
    cuisine: 'Thai',
    category: 'Main Course',
    dietaryTags: ['Vegan', 'Gluten-Free', 'Dairy-Free'],
    allergenInfo: ['Contains Soy'],
    tipsAndSubstitutions: ['Press tofu for 15 minutes before frying for extra crispiness.'],
    creatorId: 'usr_3',
    creatorName: 'Chloe Dubois',
    creatorUsername: 'chloe_nourish',
    creatorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&q=80',
    creatorIsFollowed: true,
    ingredients: [
      { id: 'i61', name: 'Extra Firm Tofu', amount: 400, unit: 'g', category: 'Produce' },
      { id: 'i62', name: 'Full Fat Coconut Milk', amount: 400, unit: 'ml', category: 'Pantry' },
      { id: 'i63', name: 'Fresh Turmeric & Ginger (grated)', amount: 2, unit: 'tbsp', category: 'Produce' },
      { id: 'i64', name: 'Sweet Potato (diced)', amount: 1, unit: 'medium', category: 'Produce' },
      { id: 'i65', name: 'Baby Spinach', amount: 100, unit: 'g', category: 'Produce' }
    ],
    steps: [
      {
        id: 's61',
        stepNumber: 1,
        title: 'Crisp Tofu',
        instruction: 'Cube pressed tofu and fry in coconut oil until golden and crisp on all sides. Set aside.'
      },
      {
        id: 's62',
        stepNumber: 2,
        title: 'Simmer Curry Base',
        instruction: 'Sauté ginger, garlic, turmeric, and curry paste. Add coconut milk and sweet potato cubes. Simmer 12 mins until tender.',
        timerMinutes: 12
      },
      {
        id: 's63',
        stepNumber: 3,
        title: 'Combine & Serve',
        instruction: 'Stir in crispy tofu and spinach until wilted. Serve over steamed jasmine rice with lime wedges.'
      }
    ],
    likesCount: 740,
    isLiked: false,
    savesCount: 290,
    isSaved: true,
    savedInCollectionIds: ['col_4'],
    averageRating: 4.7,
    ratingCount: 42,
    ratingDistribution: { 5: 35, 4: 5, 3: 2, 2: 0, 1: 0 },
    ratings: [],
    comments: [],
    createdAt: '2026-07-22T10:30:00Z',
    isPublished: true
  },
  {
    id: 'rec_7',
    title: 'Double Smash Burger with Secret Sauce',
    description: 'Two thin lacy-edge beef patties smashed over high heat with American cheese, pickles, and tangy house burger sauce on toasted brioche.',
    coverImage: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80',
    prepTimeMinutes: 10,
    cookTimeMinutes: 6,
    totalTimeMinutes: 16,
    difficulty: 'Easy',
    servings: 2,
    cuisine: 'Modern American',
    category: 'Main Course',
    dietaryTags: [],
    allergenInfo: ['Contains Dairy', 'Contains Gluten'],
    tipsAndSubstitutions: ['Use 80/20 ground chuck for juicy texture and crisp crispy edges.'],
    creatorId: 'usr_2',
    creatorName: 'Marcus Vance',
    creatorUsername: 'marcus_flame',
    creatorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80',
    creatorIsFollowed: false,
    ingredients: [
      { id: 'i71', name: 'Ground Chuck 80/20 Beef', amount: 300, unit: 'g', category: 'Meat' },
      { id: 'i72', name: 'American Cheese Slices', amount: 4, unit: 'slices', category: 'Dairy' },
      { id: 'i73', name: 'Brioche Burger Buns', amount: 2, unit: 'pcs', category: 'Bakery' },
      { id: 'i74', name: 'Dill Pickle Slices', amount: 8, unit: 'pcs', category: 'Pantry' },
      { id: 'i75', name: 'Secret Mayo Mustard Sauce', amount: 3, unit: 'tbsp', category: 'Pantry' }
    ],
    steps: [
      {
        id: 's71',
        stepNumber: 1,
        title: 'Form & Smash',
        instruction: 'Divide beef into 4 loose balls. Place on smoking hot cast iron pan and smash flat with a heavy spatula for lacy edges.',
        timerMinutes: 2
      },
      {
        id: 's72',
        stepNumber: 2,
        title: 'Flip & Melt Cheese',
        instruction: 'Flip after 2 minutes of hard searing. Place cheese slice on each patty and let melt for 1 minute.'
      },
      {
        id: 's73',
        stepNumber: 3,
        title: 'Stack & Serve',
        instruction: 'Spread secret sauce on buttered toasted brioche buns. Stack two patties, add pickles, and enjoy warm.'
      }
    ],
    likesCount: 2890,
    isLiked: false,
    savesCount: 810,
    isSaved: true,
    savedInCollectionIds: ['col_4'],
    averageRating: 4.9,
    ratingCount: 175,
    ratingDistribution: { 5: 160, 4: 12, 3: 3, 2: 0, 1: 0 },
    ratings: [],
    comments: [],
    createdAt: '2026-07-26T20:15:00Z',
    isPublished: true
  }
];

export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'n1',
    type: 'like',
    actorId: 'usr_1',
    actorName: 'Chef Elena Rostova',
    actorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80',
    recipeId: 'rec_1',
    recipeTitle: 'Truffle & Wild Mushroom Tagliatelle',
    message: 'liked your review on Truffle & Wild Mushroom Tagliatelle',
    timestamp: '15m ago',
    read: false
  },
  {
    id: 'n2',
    type: 'follow',
    actorId: 'usr_2',
    actorName: 'Marcus Vance',
    actorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80',
    message: 'started following your culinary journey',
    timestamp: '2h ago',
    read: false
  },
  {
    id: 'n3',
    type: 'comment',
    actorId: 'usr_3',
    actorName: 'Chloe Dubois',
    actorAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&q=80',
    recipeId: 'rec_1',
    recipeTitle: 'Truffle & Wild Mushroom Tagliatelle',
    message: 'commented: "Elena, this looks ethereal! Could I substitute..."',
    timestamp: '3h ago',
    read: true
  }
];

export const PRESET_FOOD_IMAGES = [
  { name: 'Gourmet Pasta', url: 'https://images.unsplash.com/photo-1621996346565-e3d5d6281232?w=800&q=80' },
  { name: 'Fresh Avocado Toast', url: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?w=800&q=80' },
  { name: 'Ahi Tuna Poke Bowl', url: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=800&q=80' },
  { name: 'Al Pastor Tacos', url: 'https://images.unsplash.com/photo-1565299585323-38d6b0865b47?w=800&q=80' },
  { name: 'Burnt Cheesecake', url: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=800&q=80' },
  { name: 'Turmeric Curry', url: 'https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?w=800&q=80' },
  { name: 'Smash Burger', url: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=800&q=80' },
  { name: 'Artisan Pizza', url: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=800&q=80' },
  { name: 'Fresh Berry Bowl', url: 'https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?w=800&q=80' },
  { name: 'Matcha Latte', url: 'https://images.unsplash.com/photo-1536256263959-770b48d82b0a?w=800&q=80' }
];
