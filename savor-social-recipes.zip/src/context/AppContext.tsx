import React, { createContext, useContext, useState, useEffect } from 'react';
import { Recipe, User, Collection, Notification, TabType, Rating, Comment } from '../types';
import { INITIAL_RECIPES, CURRENT_USER, MOCK_USERS, INITIAL_COLLECTIONS, INITIAL_NOTIFICATIONS } from '../data/mockData';

interface Toast {
  id: string;
  title: string;
  desc?: string;
  type?: 'success' | 'info' | 'warn';
}

interface AppContextType {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  selectedRecipeId: string | null;
  openRecipeDetail: (id: string) => void;
  closeRecipeDetail: () => void;
  
  recipes: Recipe[];
  currentUser: User;
  users: User[];
  collections: Collection[];
  notifications: Notification[];
  unreadNotificationCount: number;

  // Search state helpers
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  selectedFilterCuisine: string | null;
  setSelectedFilterCuisine: (c: string | null) => void;
  selectedFilterDietary: string | null;
  setSelectedFilterDietary: (d: string | null) => void;

  // Modals & Sliders
  isNotificationDrawerOpen: boolean;
  setIsNotificationDrawerOpen: (open: boolean) => void;
  shareModalRecipe: Recipe | null;
  setShareModalRecipe: (recipe: Recipe | null) => void;
  reportModalItem: { id: string; type: 'recipe' | 'comment' | 'user' } | null;
  setReportModalItem: (item: { id: string; type: 'recipe' | 'comment' | 'user' } | null) => void;
  saveCollectionModalRecipeId: string | null;
  setSaveCollectionModalRecipeId: (recipeId: string | null) => void;

  // Active cooking timer widget state
  activeTimer: { title: string; remainingSeconds: number; totalSeconds: number; recipeTitle: string } | null;
  startCookingTimer: (title: string, minutes: number, recipeTitle: string) => void;
  stopCookingTimer: () => void;

  // Core Actions
  toggleLikeRecipe: (recipeId: string) => void;
  toggleSaveRecipe: (recipeId: string, collectionId?: string) => void;
  toggleFollowUser: (userId: string) => void;
  addRating: (recipeId: string, score: number, comment?: string) => void;
  addComment: (recipeId: string, text: string, parentId?: string) => void;
  toggleLikeComment: (recipeId: string, commentId: string) => void;
  createCollection: (name: string, description: string, isPrivate: boolean) => Collection;
  publishRecipe: (recipeData: Omit<Recipe, 'id' | 'createdAt' | 'likesCount' | 'isLiked' | 'savesCount' | 'isSaved' | 'savedInCollectionIds' | 'averageRating' | 'ratingCount' | 'ratingDistribution' | 'ratings' | 'comments' | 'creatorId' | 'creatorName' | 'creatorUsername' | 'creatorAvatar'>) => Recipe;
  updateUserProfile: (updates: Partial<User>) => void;
  switchActiveUser: (userId: string) => void;
  markNotificationsRead: () => void;
  
  toast: Toast | null;
  showToast: (title: string, desc?: string, type?: 'success' | 'info' | 'warn') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY = 'savor_app_state_v1';

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTabState] = useState<TabType>('home');
  const [selectedRecipeId, setSelectedRecipeId] = useState<string | null>(null);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilterCuisine, setSelectedFilterCuisine] = useState<string | null>(null);
  const [selectedFilterDietary, setSelectedFilterDietary] = useState<string | null>(null);

  // Notification drawer & modals
  const [isNotificationDrawerOpen, setIsNotificationDrawerOpen] = useState(false);
  const [shareModalRecipe, setShareModalRecipe] = useState<Recipe | null>(null);
  const [reportModalItem, setReportModalItem] = useState<{ id: string; type: 'recipe' | 'comment' | 'user' } | null>(null);
  const [saveCollectionModalRecipeId, setSaveCollectionModalRecipeId] = useState<string | null>(null);

  // Timer widget
  const [activeTimer, setActiveTimer] = useState<{ title: string; remainingSeconds: number; totalSeconds: number; recipeTitle: string } | null>(null);

  // Toast
  const [toast, setToast] = useState<Toast | null>(null);

  // Main Persistent States
  const [recipes, setRecipes] = useState<Recipe[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_recipes`);
      return saved ? JSON.parse(saved) : INITIAL_RECIPES;
    } catch {
      return INITIAL_RECIPES;
    }
  });

  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_users`);
      return saved ? JSON.parse(saved) : MOCK_USERS;
    } catch {
      return MOCK_USERS;
    }
  });

  const [currentUser, setCurrentUser] = useState<User>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_current_user`);
      return saved ? JSON.parse(saved) : CURRENT_USER;
    } catch {
      return CURRENT_USER;
    }
  });

  const [collections, setCollections] = useState<Collection[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_collections`);
      return saved ? JSON.parse(saved) : INITIAL_COLLECTIONS;
    } catch {
      return INITIAL_COLLECTIONS;
    }
  });

  const [notifications, setNotifications] = useState<Notification[]>(() => {
    try {
      const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY}_notifications`);
      return saved ? JSON.parse(saved) : INITIAL_NOTIFICATIONS;
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_recipes`, JSON.stringify(recipes));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_users`, JSON.stringify(users));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_current_user`, JSON.stringify(currentUser));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_collections`, JSON.stringify(collections));
      localStorage.setItem(`${LOCAL_STORAGE_KEY}_notifications`, JSON.stringify(notifications));
    } catch (e) {
      console.warn('LocalStorage save failed:', e);
    }
  }, [recipes, users, currentUser, collections, notifications]);

  // Timer interval ticker
  useEffect(() => {
    if (!activeTimer) return;
    if (activeTimer.remainingSeconds <= 0) {
      showToast('Timer Complete!', `Step "${activeTimer.title}" is done!`, 'info');
      setActiveTimer(null);
      return;
    }

    const interval = setInterval(() => {
      setActiveTimer(prev => {
        if (!prev || prev.remainingSeconds <= 1) {
          showToast('Timer Complete!', `Step "${prev?.title || 'Cooking step'}" is finished!`, 'info');
          return null;
        }
        return { ...prev, remainingSeconds: prev.remainingSeconds - 1 };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [activeTimer]);

  const showToast = (title: string, desc?: string, type: 'success' | 'info' | 'warn' = 'success') => {
    const id = Date.now().toString();
    setToast({ id, title, desc, type });
    setTimeout(() => {
      setToast(current => (current?.id === id ? null : current));
    }, 3500);
  };

  const setActiveTab = (tab: TabType) => {
    setActiveTabState(tab);
    // When changing tabs, clear selected detail if navigating away unless in recipe detail
    if (tab !== 'home' && tab !== 'search') {
      setSelectedRecipeId(null);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openRecipeDetail = (id: string) => {
    setSelectedRecipeId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const closeRecipeDetail = () => {
    setSelectedRecipeId(null);
  };

  const startCookingTimer = (title: string, minutes: number, recipeTitle: string) => {
    const seconds = minutes * 60;
    setActiveTimer({
      title,
      totalSeconds: seconds,
      remainingSeconds: seconds,
      recipeTitle
    });
    showToast('Timer Started', `${minutes} min timer set for "${title}"`, 'info');
  };

  const stopCookingTimer = () => {
    setActiveTimer(null);
    showToast('Timer Cancelled', undefined, 'info');
  };

  // Social Actions
  const toggleLikeRecipe = (recipeId: string) => {
    setRecipes(prev =>
      prev.map(r => {
        if (r.id === recipeId) {
          const nextIsLiked = !r.isLiked;
          const newLikesCount = nextIsLiked ? r.likesCount + 1 : Math.max(0, r.likesCount - 1);
          if (nextIsLiked) {
            showToast('Liked Recipe', `Added "${r.title}" to your liked recipes`, 'success');
          }
          return {
            ...r,
            isLiked: nextIsLiked,
            likesCount: newLikesCount
          };
        }
        return r;
      })
    );
  };

  const toggleSaveRecipe = (recipeId: string, collectionId?: string) => {
    const recipe = recipes.find(r => r.id === recipeId);
    if (!recipe) return;

    const targetCollectionId = collectionId || 'col_1'; // default to Favourites
    const isCurrentlySaved = recipe.isSaved && (!collectionId || recipe.savedInCollectionIds.includes(targetCollectionId));

    setRecipes(prev =>
      prev.map(r => {
        if (r.id === recipeId) {
          let updatedCollections = [...r.savedInCollectionIds];
          let nextIsSaved = true;

          if (isCurrentlySaved) {
            if (collectionId) {
              updatedCollections = updatedCollections.filter(c => c !== collectionId);
              nextIsSaved = updatedCollections.length > 0;
            } else {
              updatedCollections = [];
              nextIsSaved = false;
            }
          } else {
            if (!updatedCollections.includes(targetCollectionId)) {
              updatedCollections.push(targetCollectionId);
            }
            nextIsSaved = true;
          }

          return {
            ...r,
            isSaved: nextIsSaved,
            savedInCollectionIds: updatedCollections,
            savesCount: nextIsSaved ? r.savesCount + 1 : Math.max(0, r.savesCount - 1)
          };
        }
        return r;
      })
    );

    // Update Collections
    setCollections(prevCols =>
      prevCols.map(col => {
        if (col.id === targetCollectionId) {
          const exists = col.recipeIds.includes(recipeId);
          const nextRecipeIds = exists
            ? col.recipeIds.filter(id => id !== recipeId)
            : [...col.recipeIds, recipeId];
          return { ...col, recipeIds: nextRecipeIds };
        }
        return col;
      })
    );

    const targetColObj = collections.find(c => c.id === targetCollectionId);
    if (!isCurrentlySaved) {
      showToast('Saved to Collection', `Saved to "${targetColObj?.name || 'Favourites'}"`, 'success');
    } else {
      showToast('Removed from Collection', `Removed from "${targetColObj?.name || 'Favourites'}"`, 'info');
    }
  };

  const toggleFollowUser = (userId: string) => {
    if (userId === currentUser.id) return;

    const isFollowing = currentUser.followingUserIds.includes(userId);
    const updatedFollowing = isFollowing
      ? currentUser.followingUserIds.filter(id => id !== userId)
      : [...currentUser.followingUserIds, userId];

    // Update current user
    const nextCurrentUser = {
      ...currentUser,
      followingUserIds: updatedFollowing,
      followingCount: updatedFollowing.length
    };
    setCurrentUser(nextCurrentUser);

    // Update targeted user's follower count
    setUsers(prevUsers =>
      prevUsers.map(u => {
        if (u.id === userId) {
          const newFollowers = isFollowing ? Math.max(0, u.followersCount - 1) : u.followersCount + 1;
          return { ...u, followersCount: newFollowers, isFollowing: !isFollowing };
        }
        if (u.id === currentUser.id) {
          return nextCurrentUser;
        }
        return u;
      })
    );

    // Update recipe creators flags
    setRecipes(prevRecipes =>
      prevRecipes.map(r => {
        if (r.creatorId === userId) {
          return { ...r, creatorIsFollowed: !isFollowing };
        }
        return r;
      })
    );

    const targetUser = users.find(u => u.id === userId);
    if (!isFollowing) {
      showToast('Following Creator', `Now following ${targetUser?.name || 'cook'}`, 'success');
      // Create notification
      const newNotif: Notification = {
        id: `notif_${Date.now()}`,
        type: 'follow',
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorAvatar: currentUser.avatar,
        message: 'started following you',
        timestamp: 'Just now',
        read: false
      };
      setNotifications(prev => [newNotif, ...prev]);
    } else {
      showToast('Unfollowed', `Unfollowed ${targetUser?.name || 'cook'}`, 'info');
    }
  };

  const addRating = (recipeId: string, score: number, commentText?: string) => {
    const newRating: Rating = {
      id: `rat_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      score,
      comment: commentText,
      createdAt: 'Just now'
    };

    setRecipes(prev =>
      prev.map(r => {
        if (r.id === recipeId) {
          const newRatings = [newRating, ...r.ratings];
          const totalRatingCount = r.ratingCount + 1;
          const currentDist = { ...r.ratingDistribution };
          currentDist[score] = (currentDist[score] || 0) + 1;

          // recalculate average rating
          let sum = 0;
          Object.entries(currentDist).forEach(([s, cnt]) => {
            sum += Number(s) * Number(cnt);
          });
          const newAvg = Number((sum / totalRatingCount).toFixed(1));

          return {
            ...r,
            ratings: newRatings,
            ratingCount: totalRatingCount,
            ratingDistribution: currentDist,
            averageRating: newAvg
          };
        }
        return r;
      })
    );

    showToast('Rating Submitted', `You rated this recipe ${score} stars!`, 'success');
  };

  const addComment = (recipeId: string, text: string, parentId?: string) => {
    const newComment: Comment = {
      id: `cmt_${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      userAvatar: currentUser.avatar,
      text,
      createdAt: 'Just now',
      likesCount: 0,
      isLiked: false,
      parentId,
      replies: []
    };

    setRecipes(prev =>
      prev.map(r => {
        if (r.id === recipeId) {
          if (!parentId) {
            return { ...r, comments: [newComment, ...r.comments] };
          } else {
            // Nest into parent comment
            const updatedComments = r.comments.map(c => {
              if (c.id === parentId) {
                return {
                  ...c,
                  replies: [...(c.replies || []), newComment]
                };
              }
              return c;
            });
            return { ...r, comments: updatedComments };
          }
        }
        return r;
      })
    );

    showToast('Comment Posted', 'Your message has been added.', 'success');
  };

  const toggleLikeComment = (recipeId: string, commentId: string) => {
    setRecipes(prev =>
      prev.map(r => {
        if (r.id === recipeId) {
          const updatedComments = r.comments.map(c => {
            if (c.id === commentId) {
              const isLiked = !c.isLiked;
              return {
                ...c,
                isLiked,
                likesCount: isLiked ? c.likesCount + 1 : Math.max(0, c.likesCount - 1)
              };
            }
            if (c.replies) {
              const updatedReplies = c.replies.map(rep => {
                if (rep.id === commentId) {
                  const isLiked = !rep.isLiked;
                  return {
                    ...rep,
                    isLiked,
                    likesCount: isLiked ? rep.likesCount + 1 : Math.max(0, rep.likesCount - 1)
                  };
                }
                return rep;
              });
              return { ...c, replies: updatedReplies };
            }
            return c;
          });
          return { ...r, comments: updatedComments };
        }
        return r;
      })
    );
  };

  const createCollection = (name: string, description: string, isPrivate: boolean): Collection => {
    const newCol: Collection = {
      id: `col_${Date.now()}`,
      name,
      description,
      isPrivate,
      recipeIds: [],
      createdAt: new Date().toISOString().split('T')[0]
    };
    setCollections(prev => [...prev, newCol]);
    showToast('Collection Created', `Created collection "${name}"`, 'success');
    return newCol;
  };

  const publishRecipe = (recipeData: Omit<Recipe, 'id' | 'createdAt' | 'likesCount' | 'isLiked' | 'savesCount' | 'isSaved' | 'savedInCollectionIds' | 'averageRating' | 'ratingCount' | 'ratingDistribution' | 'ratings' | 'comments' | 'creatorId' | 'creatorName' | 'creatorUsername' | 'creatorAvatar'>): Recipe => {
    const newRecipe: Recipe = {
      ...recipeData,
      id: `rec_${Date.now()}`,
      creatorId: currentUser.id,
      creatorName: currentUser.name,
      creatorUsername: currentUser.username,
      creatorAvatar: currentUser.avatar,
      creatorIsFollowed: false,
      likesCount: 0,
      isLiked: false,
      savesCount: 0,
      isSaved: false,
      savedInCollectionIds: [],
      averageRating: 5.0,
      ratingCount: 1,
      ratingDistribution: { 5: 1, 4: 0, 3: 0, 2: 0, 1: 0 },
      ratings: [],
      comments: [],
      createdAt: new Date().toISOString(),
      isPublished: true
    };

    setRecipes(prev => [newRecipe, ...prev]);

    // Update currentUser recipesCount
    const updatedUser = { ...currentUser, recipesCount: currentUser.recipesCount + 1 };
    setCurrentUser(updatedUser);
    setUsers(prev => prev.map(u => (u.id === currentUser.id ? updatedUser : u)));

    showToast('Recipe Published!', `"${newRecipe.title}" is now live on Savor`, 'success');
    return newRecipe;
  };

  const updateUserProfile = (updates: Partial<User>) => {
    const updatedUser = { ...currentUser, ...updates };
    setCurrentUser(updatedUser);
    setUsers(prev => prev.map(u => (u.id === currentUser.id ? updatedUser : u)));
    showToast('Profile Updated', 'Your profile changes have been saved', 'success');
  };

  const switchActiveUser = (userId: string) => {
    const target = users.find(u => u.id === userId);
    if (target) {
      setCurrentUser(target);
      showToast('Switched Account', `Logged in as ${target.name}`, 'info');
    }
  };

  const markNotificationsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const unreadNotificationCount = notifications.filter(n => !n.read).length;

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        selectedRecipeId,
        openRecipeDetail,
        closeRecipeDetail,
        recipes,
        currentUser,
        users,
        collections,
        notifications,
        unreadNotificationCount,

        searchQuery,
        setSearchQuery,
        selectedFilterCuisine,
        setSelectedFilterCuisine,
        selectedFilterDietary,
        setSelectedFilterDietary,

        isNotificationDrawerOpen,
        setIsNotificationDrawerOpen,
        shareModalRecipe,
        setShareModalRecipe,
        reportModalItem,
        setReportModalItem,
        saveCollectionModalRecipeId,
        setSaveCollectionModalRecipeId,

        activeTimer,
        startCookingTimer,
        stopCookingTimer,

        toggleLikeRecipe,
        toggleSaveRecipe,
        toggleFollowUser,
        addRating,
        addComment,
        toggleLikeComment,
        createCollection,
        publishRecipe,
        updateUserProfile,
        switchActiveUser,
        markNotificationsRead,

        toast,
        showToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
