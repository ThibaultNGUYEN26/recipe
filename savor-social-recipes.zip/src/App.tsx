import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/common/Header';
import { BottomNav } from './components/common/BottomNav';
import { Toast } from './components/common/Toast';
import { ShareModal } from './components/common/ShareModal';
import { ReportModal } from './components/common/ReportModal';
import { CollectionModal } from './components/common/CollectionModal';
import { TimerWidget } from './components/common/TimerWidget';
import { NotificationDrawer } from './components/notifications/NotificationDrawer';

import { HomeFeed } from './components/home/HomeFeed';
import { SearchDiscover } from './components/search/SearchDiscover';
import { RecipeDetail } from './components/detail/RecipeDetail';
import { AddRecipeFlow } from './components/add/AddRecipeFlow';
import { SavedRecipes } from './components/saved/SavedRecipes';
import { UserProfile } from './components/profile/UserProfile';

const MainContent: React.FC = () => {
  const { activeTab, selectedRecipeId } = useApp();

  if (selectedRecipeId) {
    return <RecipeDetail />;
  }

  switch (activeTab) {
    case 'home':
      return <HomeFeed />;
    case 'search':
      return <SearchDiscover />;
    case 'add':
      return <AddRecipeFlow />;
    case 'saved':
      return <SavedRecipes />;
    case 'profile':
      return <UserProfile />;
    default:
      return <HomeFeed />;
  }
};

export default function App() {
  return (
    <AppProvider>
      <div className="min-h-screen bg-[#FAF8F5] text-stone-900 selection:bg-amber-200 selection:text-amber-950 font-sans antialiased">
        <Header />

        <main className="max-w-4xl mx-auto px-4 pt-4 sm:pt-6">
          <MainContent />
        </main>

        <BottomNav />
        <Toast />
        <ShareModal />
        <ReportModal />
        <CollectionModal />
        <TimerWidget />
        <NotificationDrawer />
      </div>
    </AppProvider>
  );
}
