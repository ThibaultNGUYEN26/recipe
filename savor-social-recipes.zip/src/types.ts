export type Difficulty = 'Easy' | 'Medium' | 'Hard' | 'Chef';

export type Cuisine = 
  | 'Italian'
  | 'Japanese'
  | 'Mexican'
  | 'Mediterranean'
  | 'French'
  | 'Nordic'
  | 'Thai'
  | 'Indian'
  | 'Modern American';

export type Category = 
  | 'Main Course'
  | 'Dessert'
  | 'Breakfast'
  | 'Appetizer'
  | 'Salad'
  | 'Soup'
  | 'Pasta'
  | 'Baking'
  | 'Drinks';

export type DietaryTag = 
  | 'Vegetarian'
  | 'Vegan'
  | 'Gluten-Free'
  | 'Dairy-Free'
  | 'Low-Carb'
  | 'Nut-Free'
  | 'Keto';

export interface Ingredient {
  id: string;
  name: string;
  amount: number;
  unit: string;
  notes?: string;
  category?: string;
}

export interface Step {
  id: string;
  stepNumber: number;
  title?: string;
  instruction: string;
  tip?: string;
  timerMinutes?: number;
}

export interface Rating {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  score: number; // 1-5
  comment?: string;
  createdAt: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  text: string;
  createdAt: string;
  likesCount: number;
  isLiked?: boolean;
  parentId?: string;
  replies?: Comment[];
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  coverImage: string;
  prepTimeMinutes: number;
  cookTimeMinutes: number;
  totalTimeMinutes: number;
  difficulty: Difficulty;
  servings: number;
  cuisine: Cuisine;
  category: Category;
  dietaryTags: DietaryTag[];
  allergenInfo: string[];
  tipsAndSubstitutions: string[];
  
  // Creator info
  creatorId: string;
  creatorName: string;
  creatorUsername: string;
  creatorAvatar: string;
  creatorIsFollowed?: boolean;

  ingredients: Ingredient[];
  steps: Step[];

  // Social stats
  likesCount: number;
  isLiked: boolean;
  savesCount: number;
  isSaved: boolean;
  savedInCollectionIds: string[];
  
  averageRating: number;
  ratingCount: number;
  ratingDistribution: { [score: number]: number }; // e.g. {5: 12, 4: 3, 3: 1, 2: 0, 1: 0}
  ratings: Rating[];
  comments: Comment[];

  createdAt: string;
  isPublished: boolean;
}

export interface Collection {
  id: string;
  name: string;
  description: string;
  isPrivate: boolean;
  recipeIds: string[];
  coverImage?: string;
  createdAt: string;
}

export interface User {
  id: string;
  name: string;
  username: string;
  avatar: string;
  bio: string;
  location: string;
  followersCount: number;
  followingCount: number;
  isFollowing?: boolean;
  recipesCount: number;
  savedCount: number;
  followingUserIds: string[];
}

export interface Notification {
  id: string;
  type: 'follow' | 'like' | 'comment' | 'recipe_published' | 'rating';
  actorId: string;
  actorName: string;
  actorAvatar: string;
  recipeId?: string;
  recipeTitle?: string;
  message?: string;
  timestamp: string;
  read: boolean;
}

export type TabType = 'home' | 'search' | 'add' | 'saved' | 'profile';
